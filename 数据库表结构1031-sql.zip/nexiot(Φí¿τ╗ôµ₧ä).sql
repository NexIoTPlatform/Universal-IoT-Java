/*
 Navicat Premium Dump SQL

 Source Server         : 194
 Source Server Type    : MySQL
 Source Server Version : 80406 (8.4.6)
 Source Host           : 192.168.31.194:3307
 Source Schema         : black

 Target Server Type    : MySQL
 Target Server Version : 80406 (8.4.6)
 File Encoding         : 65001

 Date: 02/11/2025 08:33:53
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for code_protocol
-- ----------------------------
DROP TABLE IF EXISTS `code_protocol`;
CREATE TABLE `code_protocol` (
  `code_key` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '唯一key',
  `provider_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '协议类型 jar,jscript,magic',
  `class_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '协议类型为jar时,编解码类名',
  `location` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin COMMENT '编解码网络地址或者内容',
  PRIMARY KEY (`code_key`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of code_protocol
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for device_message_routes
-- ----------------------------
DROP TABLE IF EXISTS `device_message_routes`;
CREATE TABLE `device_message_routes` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `product_key` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '产品Key',
  `device_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '设备ID',
  `message_type` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '消息类型：data/status/command',
  `flow_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '流程ID',
  `priority` int DEFAULT '0' COMMENT '优先级',
  `enabled` tinyint DEFAULT '1' COMMENT '是否启用',
  `creator_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建者ID',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `uk_route` (`product_key`,`device_id`,`message_type`,`flow_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='设备消息路由表';

-- ----------------------------
-- Records of device_message_routes
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for gen_table
-- ----------------------------
DROP TABLE IF EXISTS `gen_table`;
CREATE TABLE `gen_table` (
  `table_id` bigint NOT NULL AUTO_INCREMENT COMMENT '编号',
  `table_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '表名称',
  `table_comment` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '表描述',
  `sub_table_name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '关联子表的表名',
  `sub_table_fk_name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '子表关联的外键名',
  `class_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '实体类名称',
  `tpl_category` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT 'crud' COMMENT '使用的模板（crud单表操作 tree树表操作）',
  `package_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '生成包路径',
  `module_name` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '生成模块名',
  `business_name` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '生成业务名',
  `function_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '生成功能名',
  `function_author` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '生成功能作者',
  `gen_type` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '0' COMMENT '生成代码方式（0zip压缩包 1自定义路径）',
  `gen_path` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '/' COMMENT '生成路径（不填默认项目路径）',
  `options` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '其它生成选项',
  `create_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '创建者',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '更新者',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`table_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin ROW_FORMAT=DYNAMIC COMMENT='代码生成业务表';

-- ----------------------------
-- Records of gen_table
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for gen_table_column
-- ----------------------------
DROP TABLE IF EXISTS `gen_table_column`;
CREATE TABLE `gen_table_column` (
  `column_id` bigint NOT NULL AUTO_INCREMENT COMMENT '编号',
  `table_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '归属表编号',
  `column_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '列名称',
  `column_comment` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '列描述',
  `column_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '列类型',
  `java_type` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'JAVA类型',
  `java_field` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'JAVA字段名',
  `is_pk` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '是否主键（1是）',
  `is_increment` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '是否自增（1是）',
  `is_required` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '是否必填（1是）',
  `is_insert` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '是否为插入字段（1是）',
  `is_edit` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '是否编辑字段（1是）',
  `is_list` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '是否列表字段（1是）',
  `is_query` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '是否查询字段（1是）',
  `query_type` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT 'EQ' COMMENT '查询方式（等于、不等于、大于、小于、范围）',
  `html_type` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '显示类型（文本框、文本域、下拉框、复选框、单选框、日期控件）',
  `dict_type` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '字典类型',
  `sort` int DEFAULT NULL COMMENT '排序',
  `create_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '创建者',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '更新者',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`column_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=97 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin ROW_FORMAT=DYNAMIC COMMENT='代码生成业务表字段';

-- ----------------------------
-- Records of gen_table_column
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for iot_certificate
-- ----------------------------
DROP TABLE IF EXISTS `iot_certificate`;
CREATE TABLE `iot_certificate` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `ssl_key` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '证书唯一标识（sslKey）',
  `name` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '证书名称',
  `cert_content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '证书内容（PEM，Base64或加密）',
  `key_content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '私钥内容（PEM，Base64或加密）',
  `cert_password` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '证书密码（如有）',
  `key_password` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '私钥密码（如有）',
  `cert_info` json DEFAULT NULL COMMENT '证书信息',
  `expire_time` datetime DEFAULT NULL COMMENT '到期时间',
  `remark` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '备注',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `create_user` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT '创建者用户ID',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `uniq_ssl_key` (`ssl_key`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC COMMENT='物联网产品证书表（内容存数据库）';

-- ----------------------------
-- Records of iot_certificate
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for iot_dashboard_statistics
-- ----------------------------
DROP TABLE IF EXISTS `iot_dashboard_statistics`;
CREATE TABLE `iot_dashboard_statistics` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `stat_date` date NOT NULL COMMENT '统计日期',
  `product_key` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '产品Key，NULL表示全产品',
  `channel` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '推送渠道，NULL表示全渠道',
  `metric_type` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '指标类型(device_total/device_online/message_total/message_success/message_failed)',
  `metric_value` bigint NOT NULL DEFAULT '0' COMMENT '指标值',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `uk_date_product_channel_metric` (`stat_date`,`product_key`,`channel`,`metric_type`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3111 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC COMMENT='仪表盘统计表';

-- ----------------------------
-- Records of iot_dashboard_statistics
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for iot_data_bridge_config
-- ----------------------------
DROP TABLE IF EXISTS `iot_data_bridge_config`;
CREATE TABLE `iot_data_bridge_config` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '配置名称',
  `source_scope` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT 'ALL_PRODUCTS' COMMENT '源范围：ALL_PRODUCTS/SPECIFIC_PRODUCTS/APPLICATION',
  `source_product_keys` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci COMMENT '源产品KEY列表JSON（source_scope=SPECIFIC_PRODUCTS时使用）',
  `source_application_id` bigint DEFAULT NULL COMMENT '源应用ID（source_scope=APPLICATION时使用）',
  `target_resource_id` bigint NOT NULL COMMENT '目标资源ID（不加外键约束）',
  `bridge_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '桥接类型(JDBC,KAFKA,MQTT,HTTP,IOTDB,INFLUXDB等)',
  `template` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '模板内容（SQL、JSON等）',
  `magic_script` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci COMMENT 'Magic脚本内容（用户自定义处理逻辑）',
  `config` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci COMMENT '统一配置JSON',
  `status` tinyint DEFAULT '1' COMMENT '状态(0:禁用,1:启用)',
  `description` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '描述',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `create_by` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建者',
  `update_by` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新者',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `idx_source_scope` (`source_scope`) USING BTREE,
  KEY `idx_target_resource_id` (`target_resource_id`) USING BTREE,
  KEY `idx_bridge_type` (`bridge_type`) USING BTREE,
  KEY `idx_status` (`status`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='数据桥接配置表';

-- ----------------------------
-- Records of iot_data_bridge_config
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for iot_data_input_log
-- ----------------------------
DROP TABLE IF EXISTS `iot_data_input_log`;
CREATE TABLE `iot_data_input_log` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `config_id` bigint NOT NULL COMMENT '配置ID',
  `config_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '配置名称',
  `source_system` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '源系统',
  `message_count` int DEFAULT '0' COMMENT '消息数量',
  `success_count` int DEFAULT '0' COMMENT '成功数量',
  `failed_count` int DEFAULT '0' COMMENT '失败数量',
  `error_message` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci COMMENT '错误信息',
  `execution_time` bigint DEFAULT '0' COMMENT '执行时间(毫秒)',
  `status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '状态：SUCCESS,FAILED,RUNNING',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `create_by` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建者',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `idx_config_id` (`config_id`) USING BTREE,
  KEY `idx_status` (`status`) USING BTREE,
  KEY `idx_create_time` (`create_time`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='数据输入日志表';

-- ----------------------------
-- Records of iot_data_input_log
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for iot_data_input_task
-- ----------------------------
DROP TABLE IF EXISTS `iot_data_input_task`;
CREATE TABLE `iot_data_input_task` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `config_id` bigint NOT NULL COMMENT '配置ID',
  `task_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '任务名称',
  `task_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '任务类型：SCHEDULED-定时，REALTIME-实时',
  `cron_expression` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT 'Cron表达式',
  `last_execution_time` datetime DEFAULT NULL COMMENT '最后执行时间',
  `next_execution_time` datetime DEFAULT NULL COMMENT '下次执行时间',
  `status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT 'STOPPED' COMMENT '状态：RUNNING,STOPPED,ERROR',
  `error_message` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci COMMENT '错误信息',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `create_by` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建者',
  `update_by` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新者',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `uk_config_id` (`config_id`) USING BTREE,
  KEY `idx_status` (`status`) USING BTREE,
  KEY `idx_next_execution_time` (`next_execution_time`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='数据输入任务表';

-- ----------------------------
-- Records of iot_data_input_task
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for iot_device
-- ----------------------------
DROP TABLE IF EXISTS `iot_device`;
CREATE TABLE `iot_device` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `iot_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '本平台设备唯一标识符',
  `device_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '设备自身序号',
  `ext_device_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '第三方平台设备ID唯一标识符',
  `derive_metadata` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci COMMENT '派生元数据,有的设备的属性，功能，事件可能会动态的添加',
  `configuration` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci COMMENT '其他配置',
  `product_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '产品名称',
  `gw_product_key` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '网关产品ProductKey',
  `device_secret` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '1设备密钥',
  `product_key` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '产品实例',
  `device_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '设备实例名称',
  `creator_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `instance` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '0' COMMENT '实例名称',
  `application` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '归属应用',
  `state` tinyint(1) DEFAULT NULL COMMENT '0-离线，1-在线',
  `detail` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '说明',
  `create_time` bigint unsigned DEFAULT NULL COMMENT '创建时间',
  `registry_time` bigint unsigned DEFAULT NULL COMMENT '激活时间',
  `online_time` bigint unsigned DEFAULT NULL COMMENT '最后通信时间',
  `areas_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '区域ID',
  `coordinate` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '坐标',
  `ext1` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '扩展字段1',
  `ext2` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '扩展字段2',
  `ext3` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '扩展字段3',
  `ext4` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '扩展字段4',
  `signal_strength` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT 'CSQ信号强度',
  `device_tag` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '设备标签',
  `device_address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '设备地址',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `idx_device_id` (`product_key`,`device_id`) USING BTREE,
  KEY `idx_iot_id` (`iot_id`) USING BTREE,
  KEY `idx_device_name` (`device_name`) USING BTREE,
  KEY `idx_creator_id` (`creator_id`) USING BTREE,
  KEY `idx_online` (`product_key`,`state`,`online_time`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=211 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC COMMENT='设备表';

-- ----------------------------
-- Records of iot_device
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for iot_device_fence_rel
-- ----------------------------
DROP TABLE IF EXISTS `iot_device_fence_rel`;
CREATE TABLE `iot_device_fence_rel` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `fence_id` bigint NOT NULL COMMENT '围栏id',
  `iot_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '设备唯一标识符',
  `device_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '设备序列号',
  `creator_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '创建人',
  `create_date` datetime DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin ROW_FORMAT=DYNAMIC COMMENT='设备和围栏中间表';

-- ----------------------------
-- Records of iot_device_fence_rel
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for iot_device_function_history
-- ----------------------------
DROP TABLE IF EXISTS `iot_device_function_history`;
CREATE TABLE `iot_device_function_history` (
  `id` bigint NOT NULL,
  `product_key` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '产品key',
  `iot_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `device_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '设备序列号',
  `device_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '设备名称',
  `ext_param` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '{}' COMMENT '额外参数',
  `down_state` tinyint DEFAULT NULL COMMENT '指令配置状态  0.待下发；1.下发中；2.已下发',
  `down_result` tinyint DEFAULT NULL COMMENT '下发结果 0.失败  1.成功',
  `down_error` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '异常信息',
  `task_id` bigint DEFAULT NULL COMMENT '所属任务id',
  `update_time` datetime DEFAULT NULL COMMENT '下发时间',
  `retry` int DEFAULT '0' COMMENT '下发次数',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin ROW_FORMAT=DYNAMIC COMMENT='设备功能批量下发历史';

-- ----------------------------
-- Records of iot_device_function_history
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for iot_device_function_task
-- ----------------------------
DROP TABLE IF EXISTS `iot_device_function_task`;
CREATE TABLE `iot_device_function_task` (
  `id` bigint NOT NULL,
  `task_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '任务名称',
  `product_key` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `begin_time` datetime DEFAULT NULL COMMENT '任务开始时间',
  `end_time` datetime DEFAULT NULL COMMENT '任务结束时间',
  `creator` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '创建人姓名',
  `creator_id` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '创建人',
  `command` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '功能指令',
  `command_data` varchar(800) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '指令内容',
  `status` tinyint DEFAULT NULL COMMENT '状态  0.待执行；1.已执行；2.正在执行',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `dev_function_task_id_uindex` (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin ROW_FORMAT=DYNAMIC COMMENT='设备功能批量下发任务表';

-- ----------------------------
-- Records of iot_device_function_task
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for iot_device_geo_fence
-- ----------------------------
DROP TABLE IF EXISTS `iot_device_geo_fence`;
CREATE TABLE `iot_device_geo_fence` (
  `id` bigint NOT NULL COMMENT 'id',
  `name` varchar(60) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '围栏名称',
  `status` tinyint DEFAULT NULL COMMENT '围栏状态 0.启用 1.停用',
  `touch_way` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '触发模式 in.进入 out.离开 all.进入&离开',
  `fence` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin COMMENT '范围',
  `type` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '类型 circle.圆 polygon.多边形',
  `point` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '圆形中心点',
  `radius` decimal(16,8) DEFAULT NULL COMMENT '半径',
  `creator_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '创建人',
  `create_date` datetime DEFAULT NULL COMMENT '创建时间',
  `update_date` datetime DEFAULT NULL COMMENT '更新时间',
  `week_time` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '每周触发时间(天)',
  `begin_time` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '每天开始时间',
  `end_time` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '每天结束时间',
  `creator_user` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '归属第三方应用',
  `no_trigger_time` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '不触发时间段',
  `delay_time` int DEFAULT NULL COMMENT '围栏触发延迟时间（分钟）',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin ROW_FORMAT=DYNAMIC COMMENT='设备围栏表';

-- ----------------------------
-- Records of iot_device_geo_fence
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for iot_device_group
-- ----------------------------
DROP TABLE IF EXISTS `iot_device_group`;
CREATE TABLE `iot_device_group` (
  `id` bigint NOT NULL COMMENT '分组ID，非自增',
  `group_name` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '分组名称',
  `group_code` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '分组标识',
  `group_describe` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '群组描述',
  `parent_id` bigint DEFAULT '0' COMMENT '父id',
  `group_level` tinyint(1) NOT NULL DEFAULT '0' COMMENT '分组级别',
  `has_child` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否有子分组',
  `active_dev_count` int(10) unsigned zerofill DEFAULT NULL COMMENT '关联设备树',
  `relat_dev_count` int(10) unsigned zerofill DEFAULT NULL COMMENT '激活设备数',
  `tag` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '标签',
  `instance` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '0' COMMENT '实例编号',
  `creator_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '创建人',
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin ROW_FORMAT=DYNAMIC COMMENT='设备分组表';

-- ----------------------------
-- Records of iot_device_group
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for iot_device_history
-- ----------------------------
DROP TABLE IF EXISTS `iot_device_history`;
CREATE TABLE `iot_device_history` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `device_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '设备序列号',
  `device_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '设备名称',
  `product_key` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '产品唯一标识',
  `coordinate` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '坐标(经纬度)',
  `first_online_time` bigint DEFAULT NULL COMMENT '上线时间',
  `creater` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '设备创建者',
  `delete_time` bigint DEFAULT NULL COMMENT '设备删除时间',
  `create_time` bigint DEFAULT NULL COMMENT '设备创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of iot_device_history
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for iot_device_log
-- ----------------------------
DROP TABLE IF EXISTS `iot_device_log`;
CREATE TABLE `iot_device_log` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `iot_id` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '唯一编码',
  `device_id` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '设备自身序号',
  `ext_device_id` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '第三方设备ID唯一标识符',
  `product_key` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '产品ID',
  `device_name` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '设备名称',
  `message_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '消息类型',
  `company_no` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `protocol` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '协议',
  `device_node` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '节点类型',
  `classified_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `command_id` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '指令ID',
  `command_status` tinyint DEFAULT NULL COMMENT '指令状态',
  `org_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `event` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '事件名称',
  `create_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `instance` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '0' COMMENT '实例名称',
  `point` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '经纬度',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin COMMENT '内容',
  `create_time` int(10) unsigned zerofill DEFAULT '0000000000' COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `idx_iot_id` (`iot_id`) USING BTREE,
  KEY `idx_create_date` (`create_time`) USING BTREE,
  KEY `idx_device_product_Key` (`device_id`,`product_key`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of iot_device_log
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for iot_device_log_0
-- ----------------------------
DROP TABLE IF EXISTS `iot_device_log_0`;
CREATE TABLE `iot_device_log_0` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `iot_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '设备唯一编码',
  `product_key` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '产品ID',
  `device_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '设备自身序号',
  `device_name` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '设备名称',
  `message_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '消息类型（EVENT/PROPERTIES/FUNCTIONS）',
  `command_id` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '指令ID',
  `command_status` tinyint DEFAULT '0' COMMENT '指令状态（0未执行/1成功/2失败）',
  `event` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '事件名称（如online/offline）',
  `point` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '经纬度（经度,纬度）',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin COMMENT '日志详情（JSON格式）',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间（无0值）',
  PRIMARY KEY (`id`,`create_time`) USING BTREE,
  KEY `idx_iot_id` (`iot_id`) USING BTREE,
  KEY `idx_product_device` (`product_key`,`device_id`) USING BTREE,
  KEY `idx_event_time` (`event`,`create_time`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin ROW_FORMAT=DYNAMIC COMMENT='设备日志分表0（按iotId哈希，内部分区）'
/*!50100 PARTITION BY RANGE (to_days(`create_time`))
(PARTITION p202509 VALUES LESS THAN (739890) ENGINE = InnoDB,
 PARTITION p202510 VALUES LESS THAN (739921) ENGINE = InnoDB,
 PARTITION p202511 VALUES LESS THAN (739951) ENGINE = InnoDB,
 PARTITION pmax VALUES LESS THAN MAXVALUE ENGINE = InnoDB) */;

-- ----------------------------
-- Records of iot_device_log_0
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for iot_device_log_1
-- ----------------------------
DROP TABLE IF EXISTS `iot_device_log_1`;
CREATE TABLE `iot_device_log_1` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `iot_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '设备唯一编码',
  `product_key` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '产品ID',
  `device_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '设备自身序号',
  `device_name` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '设备名称',
  `message_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '消息类型（EVENT/PROPERTIES/FUNCTIONS）',
  `command_id` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '指令ID',
  `command_status` tinyint DEFAULT '0' COMMENT '指令状态（0未执行/1成功/2失败）',
  `event` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '事件名称（如online/offline）',
  `point` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '经纬度（经度,纬度）',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin COMMENT '日志详情（JSON格式）',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间（无0值）',
  PRIMARY KEY (`id`,`create_time`) USING BTREE,
  KEY `idx_iot_id` (`iot_id`) USING BTREE,
  KEY `idx_product_device` (`product_key`,`device_id`) USING BTREE,
  KEY `idx_event_time` (`event`,`create_time`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin ROW_FORMAT=DYNAMIC COMMENT='设备日志分表1（按iotId哈希，内部分区）'
/*!50100 PARTITION BY RANGE (to_days(`create_time`))
(PARTITION p202509 VALUES LESS THAN (739890) ENGINE = InnoDB,
 PARTITION p202510 VALUES LESS THAN (739921) ENGINE = InnoDB,
 PARTITION p202511 VALUES LESS THAN (739951) ENGINE = InnoDB,
 PARTITION pmax VALUES LESS THAN MAXVALUE ENGINE = InnoDB) */;

-- ----------------------------
-- Records of iot_device_log_1
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for iot_device_log_10
-- ----------------------------
DROP TABLE IF EXISTS `iot_device_log_10`;
CREATE TABLE `iot_device_log_10` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `iot_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '设备唯一编码',
  `product_key` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '产品ID',
  `device_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '设备自身序号',
  `device_name` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '设备名称',
  `message_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '消息类型（EVENT/PROPERTIES/FUNCTIONS）',
  `command_id` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '指令ID',
  `command_status` tinyint DEFAULT '0' COMMENT '指令状态（0未执行/1成功/2失败）',
  `event` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '事件名称（如online/offline）',
  `point` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '经纬度（经度,纬度）',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin COMMENT '日志详情（JSON格式）',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间（无0值）',
  PRIMARY KEY (`id`,`create_time`) USING BTREE,
  KEY `idx_iot_id` (`iot_id`) USING BTREE,
  KEY `idx_product_device` (`product_key`,`device_id`) USING BTREE,
  KEY `idx_event_time` (`event`,`create_time`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin ROW_FORMAT=DYNAMIC COMMENT='设备日志分表10（按iotId哈希，内部分区）'
/*!50100 PARTITION BY RANGE (to_days(`create_time`))
(PARTITION p202509 VALUES LESS THAN (739890) ENGINE = InnoDB,
 PARTITION p202510 VALUES LESS THAN (739921) ENGINE = InnoDB,
 PARTITION p202511 VALUES LESS THAN (739951) ENGINE = InnoDB,
 PARTITION pmax VALUES LESS THAN MAXVALUE ENGINE = InnoDB) */;

-- ----------------------------
-- Records of iot_device_log_10
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for iot_device_log_11
-- ----------------------------
DROP TABLE IF EXISTS `iot_device_log_11`;
CREATE TABLE `iot_device_log_11` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `iot_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '设备唯一编码',
  `product_key` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '产品ID',
  `device_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '设备自身序号',
  `device_name` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '设备名称',
  `message_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '消息类型（EVENT/PROPERTIES/FUNCTIONS）',
  `command_id` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '指令ID',
  `command_status` tinyint DEFAULT '0' COMMENT '指令状态（0未执行/1成功/2失败）',
  `event` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '事件名称（如online/offline）',
  `point` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '经纬度（经度,纬度）',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin COMMENT '日志详情（JSON格式）',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间（无0值）',
  PRIMARY KEY (`id`,`create_time`) USING BTREE,
  KEY `idx_iot_id` (`iot_id`) USING BTREE,
  KEY `idx_product_device` (`product_key`,`device_id`) USING BTREE,
  KEY `idx_event_time` (`event`,`create_time`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=25570 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin ROW_FORMAT=DYNAMIC COMMENT='设备日志分表11（按iotId哈希，内部分区）'
/*!50100 PARTITION BY RANGE (to_days(`create_time`))
(PARTITION p202509 VALUES LESS THAN (739890) ENGINE = InnoDB,
 PARTITION p202510 VALUES LESS THAN (739921) ENGINE = InnoDB,
 PARTITION p202511 VALUES LESS THAN (739951) ENGINE = InnoDB,
 PARTITION pmax VALUES LESS THAN MAXVALUE ENGINE = InnoDB) */;

-- ----------------------------
-- Records of iot_device_log_11
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for iot_device_log_12
-- ----------------------------
DROP TABLE IF EXISTS `iot_device_log_12`;
CREATE TABLE `iot_device_log_12` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `iot_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '设备唯一编码',
  `product_key` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '产品ID',
  `device_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '设备自身序号',
  `device_name` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '设备名称',
  `message_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '消息类型（EVENT/PROPERTIES/FUNCTIONS）',
  `command_id` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '指令ID',
  `command_status` tinyint DEFAULT '0' COMMENT '指令状态（0未执行/1成功/2失败）',
  `event` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '事件名称（如online/offline）',
  `point` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '经纬度（经度,纬度）',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin COMMENT '日志详情（JSON格式）',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间（无0值）',
  PRIMARY KEY (`id`,`create_time`) USING BTREE,
  KEY `idx_iot_id` (`iot_id`) USING BTREE,
  KEY `idx_product_device` (`product_key`,`device_id`) USING BTREE,
  KEY `idx_event_time` (`event`,`create_time`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin ROW_FORMAT=DYNAMIC COMMENT='设备日志分表12（按iotId哈希，内部分区）'
/*!50100 PARTITION BY RANGE (to_days(`create_time`))
(PARTITION p202509 VALUES LESS THAN (739890) ENGINE = InnoDB,
 PARTITION p202510 VALUES LESS THAN (739921) ENGINE = InnoDB,
 PARTITION p202511 VALUES LESS THAN (739951) ENGINE = InnoDB,
 PARTITION pmax VALUES LESS THAN MAXVALUE ENGINE = InnoDB) */;

-- ----------------------------
-- Records of iot_device_log_12
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for iot_device_log_13
-- ----------------------------
DROP TABLE IF EXISTS `iot_device_log_13`;
CREATE TABLE `iot_device_log_13` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `iot_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '设备唯一编码',
  `product_key` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '产品ID',
  `device_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '设备自身序号',
  `device_name` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '设备名称',
  `message_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '消息类型（EVENT/PROPERTIES/FUNCTIONS）',
  `command_id` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '指令ID',
  `command_status` tinyint DEFAULT '0' COMMENT '指令状态（0未执行/1成功/2失败）',
  `event` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '事件名称（如online/offline）',
  `point` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '经纬度（经度,纬度）',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin COMMENT '日志详情（JSON格式）',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间（无0值）',
  PRIMARY KEY (`id`,`create_time`) USING BTREE,
  KEY `idx_iot_id` (`iot_id`) USING BTREE,
  KEY `idx_product_device` (`product_key`,`device_id`) USING BTREE,
  KEY `idx_event_time` (`event`,`create_time`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=6187 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin ROW_FORMAT=DYNAMIC COMMENT='设备日志分表13（按iotId哈希，内部分区）'
/*!50100 PARTITION BY RANGE (to_days(`create_time`))
(PARTITION p202509 VALUES LESS THAN (739890) ENGINE = InnoDB,
 PARTITION p202510 VALUES LESS THAN (739921) ENGINE = InnoDB,
 PARTITION p202511 VALUES LESS THAN (739951) ENGINE = InnoDB,
 PARTITION pmax VALUES LESS THAN MAXVALUE ENGINE = InnoDB) */;

-- ----------------------------
-- Records of iot_device_log_13
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for iot_device_log_14
-- ----------------------------
DROP TABLE IF EXISTS `iot_device_log_14`;
CREATE TABLE `iot_device_log_14` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `iot_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '设备唯一编码',
  `product_key` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '产品ID',
  `device_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '设备自身序号',
  `device_name` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '设备名称',
  `message_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '消息类型（EVENT/PROPERTIES/FUNCTIONS）',
  `command_id` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '指令ID',
  `command_status` tinyint DEFAULT '0' COMMENT '指令状态（0未执行/1成功/2失败）',
  `event` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '事件名称（如online/offline）',
  `point` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '经纬度（经度,纬度）',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin COMMENT '日志详情（JSON格式）',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间（无0值）',
  PRIMARY KEY (`id`,`create_time`) USING BTREE,
  KEY `idx_iot_id` (`iot_id`) USING BTREE,
  KEY `idx_product_device` (`product_key`,`device_id`) USING BTREE,
  KEY `idx_event_time` (`event`,`create_time`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin ROW_FORMAT=DYNAMIC COMMENT='设备日志分表14（按iotId哈希，内部分区）'
/*!50100 PARTITION BY RANGE (to_days(`create_time`))
(PARTITION p202509 VALUES LESS THAN (739890) ENGINE = InnoDB,
 PARTITION p202510 VALUES LESS THAN (739921) ENGINE = InnoDB,
 PARTITION p202511 VALUES LESS THAN (739951) ENGINE = InnoDB,
 PARTITION pmax VALUES LESS THAN MAXVALUE ENGINE = InnoDB) */;

-- ----------------------------
-- Records of iot_device_log_14
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for iot_device_log_15
-- ----------------------------
DROP TABLE IF EXISTS `iot_device_log_15`;
CREATE TABLE `iot_device_log_15` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `iot_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '设备唯一编码',
  `product_key` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '产品ID',
  `device_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '设备自身序号',
  `device_name` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '设备名称',
  `message_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '消息类型（EVENT/PROPERTIES/FUNCTIONS）',
  `command_id` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '指令ID',
  `command_status` tinyint DEFAULT '0' COMMENT '指令状态（0未执行/1成功/2失败）',
  `event` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '事件名称（如online/offline）',
  `point` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '经纬度（经度,纬度）',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin COMMENT '日志详情（JSON格式）',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间（无0值）',
  PRIMARY KEY (`id`,`create_time`) USING BTREE,
  KEY `idx_iot_id` (`iot_id`) USING BTREE,
  KEY `idx_product_device` (`product_key`,`device_id`) USING BTREE,
  KEY `idx_event_time` (`event`,`create_time`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=8907 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin ROW_FORMAT=DYNAMIC COMMENT='设备日志分表15（按iotId哈希，内部分区）'
/*!50100 PARTITION BY RANGE (to_days(`create_time`))
(PARTITION p202509 VALUES LESS THAN (739890) ENGINE = InnoDB,
 PARTITION p202510 VALUES LESS THAN (739921) ENGINE = InnoDB,
 PARTITION p202511 VALUES LESS THAN (739951) ENGINE = InnoDB,
 PARTITION pmax VALUES LESS THAN MAXVALUE ENGINE = InnoDB) */;

-- ----------------------------
-- Records of iot_device_log_15
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for iot_device_log_16
-- ----------------------------
DROP TABLE IF EXISTS `iot_device_log_16`;
CREATE TABLE `iot_device_log_16` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `iot_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '设备唯一编码',
  `product_key` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '产品ID',
  `device_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '设备自身序号',
  `device_name` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '设备名称',
  `message_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '消息类型（EVENT/PROPERTIES/FUNCTIONS）',
  `command_id` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '指令ID',
  `command_status` tinyint DEFAULT '0' COMMENT '指令状态（0未执行/1成功/2失败）',
  `event` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '事件名称（如online/offline）',
  `point` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '经纬度（经度,纬度）',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin COMMENT '日志详情（JSON格式）',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间（无0值）',
  PRIMARY KEY (`id`,`create_time`) USING BTREE,
  KEY `idx_iot_id` (`iot_id`) USING BTREE,
  KEY `idx_product_device` (`product_key`,`device_id`) USING BTREE,
  KEY `idx_event_time` (`event`,`create_time`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin ROW_FORMAT=DYNAMIC COMMENT='设备日志分表16（按iotId哈希，内部分区）'
/*!50100 PARTITION BY RANGE (to_days(`create_time`))
(PARTITION p202509 VALUES LESS THAN (739890) ENGINE = InnoDB,
 PARTITION p202510 VALUES LESS THAN (739921) ENGINE = InnoDB,
 PARTITION p202511 VALUES LESS THAN (739951) ENGINE = InnoDB,
 PARTITION pmax VALUES LESS THAN MAXVALUE ENGINE = InnoDB) */;

-- ----------------------------
-- Records of iot_device_log_16
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for iot_device_log_17
-- ----------------------------
DROP TABLE IF EXISTS `iot_device_log_17`;
CREATE TABLE `iot_device_log_17` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `iot_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '设备唯一编码',
  `product_key` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '产品ID',
  `device_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '设备自身序号',
  `device_name` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '设备名称',
  `message_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '消息类型（EVENT/PROPERTIES/FUNCTIONS）',
  `command_id` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '指令ID',
  `command_status` tinyint DEFAULT '0' COMMENT '指令状态（0未执行/1成功/2失败）',
  `event` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '事件名称（如online/offline）',
  `point` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '经纬度（经度,纬度）',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin COMMENT '日志详情（JSON格式）',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间（无0值）',
  PRIMARY KEY (`id`,`create_time`) USING BTREE,
  KEY `idx_iot_id` (`iot_id`) USING BTREE,
  KEY `idx_product_device` (`product_key`,`device_id`) USING BTREE,
  KEY `idx_event_time` (`event`,`create_time`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin ROW_FORMAT=DYNAMIC COMMENT='设备日志分表17（按iotId哈希，内部分区）'
/*!50100 PARTITION BY RANGE (to_days(`create_time`))
(PARTITION p202509 VALUES LESS THAN (739890) ENGINE = InnoDB,
 PARTITION p202510 VALUES LESS THAN (739921) ENGINE = InnoDB,
 PARTITION p202511 VALUES LESS THAN (739951) ENGINE = InnoDB,
 PARTITION pmax VALUES LESS THAN MAXVALUE ENGINE = InnoDB) */;

-- ----------------------------
-- Records of iot_device_log_17
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for iot_device_log_18
-- ----------------------------
DROP TABLE IF EXISTS `iot_device_log_18`;
CREATE TABLE `iot_device_log_18` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `iot_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '设备唯一编码',
  `product_key` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '产品ID',
  `device_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '设备自身序号',
  `device_name` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '设备名称',
  `message_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '消息类型（EVENT/PROPERTIES/FUNCTIONS）',
  `command_id` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '指令ID',
  `command_status` tinyint DEFAULT '0' COMMENT '指令状态（0未执行/1成功/2失败）',
  `event` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '事件名称（如online/offline）',
  `point` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '经纬度（经度,纬度）',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin COMMENT '日志详情（JSON格式）',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间（无0值）',
  PRIMARY KEY (`id`,`create_time`) USING BTREE,
  KEY `idx_iot_id` (`iot_id`) USING BTREE,
  KEY `idx_product_device` (`product_key`,`device_id`) USING BTREE,
  KEY `idx_event_time` (`event`,`create_time`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=11568 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin ROW_FORMAT=DYNAMIC COMMENT='设备日志分表18（按iotId哈希，内部分区）'
/*!50100 PARTITION BY RANGE (to_days(`create_time`))
(PARTITION p202509 VALUES LESS THAN (739890) ENGINE = InnoDB,
 PARTITION p202510 VALUES LESS THAN (739921) ENGINE = InnoDB,
 PARTITION p202511 VALUES LESS THAN (739951) ENGINE = InnoDB,
 PARTITION pmax VALUES LESS THAN MAXVALUE ENGINE = InnoDB) */;

-- ----------------------------
-- Records of iot_device_log_18
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for iot_device_log_19
-- ----------------------------
DROP TABLE IF EXISTS `iot_device_log_19`;
CREATE TABLE `iot_device_log_19` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `iot_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '设备唯一编码',
  `product_key` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '产品ID',
  `device_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '设备自身序号',
  `device_name` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '设备名称',
  `message_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '消息类型（EVENT/PROPERTIES/FUNCTIONS）',
  `command_id` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '指令ID',
  `command_status` tinyint DEFAULT '0' COMMENT '指令状态（0未执行/1成功/2失败）',
  `event` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '事件名称（如online/offline）',
  `point` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '经纬度（经度,纬度）',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin COMMENT '日志详情（JSON格式）',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间（无0值）',
  PRIMARY KEY (`id`,`create_time`) USING BTREE,
  KEY `idx_iot_id` (`iot_id`) USING BTREE,
  KEY `idx_product_device` (`product_key`,`device_id`) USING BTREE,
  KEY `idx_event_time` (`event`,`create_time`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin ROW_FORMAT=DYNAMIC COMMENT='设备日志分表19（按iotId哈希，内部分区）'
/*!50100 PARTITION BY RANGE (to_days(`create_time`))
(PARTITION p202509 VALUES LESS THAN (739890) ENGINE = InnoDB,
 PARTITION p202510 VALUES LESS THAN (739921) ENGINE = InnoDB,
 PARTITION p202511 VALUES LESS THAN (739951) ENGINE = InnoDB,
 PARTITION pmax VALUES LESS THAN MAXVALUE ENGINE = InnoDB) */;

-- ----------------------------
-- Records of iot_device_log_19
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for iot_device_log_2
-- ----------------------------
DROP TABLE IF EXISTS `iot_device_log_2`;
CREATE TABLE `iot_device_log_2` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `iot_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '设备唯一编码',
  `product_key` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '产品ID',
  `device_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '设备自身序号',
  `device_name` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '设备名称',
  `message_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '消息类型（EVENT/PROPERTIES/FUNCTIONS）',
  `command_id` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '指令ID',
  `command_status` tinyint DEFAULT '0' COMMENT '指令状态（0未执行/1成功/2失败）',
  `event` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '事件名称（如online/offline）',
  `point` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '经纬度（经度,纬度）',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin COMMENT '日志详情（JSON格式）',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间（无0值）',
  PRIMARY KEY (`id`,`create_time`) USING BTREE,
  KEY `idx_iot_id` (`iot_id`) USING BTREE,
  KEY `idx_product_device` (`product_key`,`device_id`) USING BTREE,
  KEY `idx_event_time` (`event`,`create_time`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin ROW_FORMAT=DYNAMIC COMMENT='设备日志分表2（按iotId哈希，内部分区）'
/*!50100 PARTITION BY RANGE (to_days(`create_time`))
(PARTITION p202509 VALUES LESS THAN (739890) ENGINE = InnoDB,
 PARTITION p202510 VALUES LESS THAN (739921) ENGINE = InnoDB,
 PARTITION p202511 VALUES LESS THAN (739951) ENGINE = InnoDB,
 PARTITION pmax VALUES LESS THAN MAXVALUE ENGINE = InnoDB) */;

-- ----------------------------
-- Records of iot_device_log_2
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for iot_device_log_20
-- ----------------------------
DROP TABLE IF EXISTS `iot_device_log_20`;
CREATE TABLE `iot_device_log_20` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `iot_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '设备唯一编码',
  `product_key` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '产品ID',
  `device_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '设备自身序号',
  `device_name` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '设备名称',
  `message_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '消息类型（EVENT/PROPERTIES/FUNCTIONS）',
  `command_id` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '指令ID',
  `command_status` tinyint DEFAULT '0' COMMENT '指令状态（0未执行/1成功/2失败）',
  `event` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '事件名称（如online/offline）',
  `point` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '经纬度（经度,纬度）',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin COMMENT '日志详情（JSON格式）',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间（无0值）',
  PRIMARY KEY (`id`,`create_time`) USING BTREE,
  KEY `idx_iot_id` (`iot_id`) USING BTREE,
  KEY `idx_product_device` (`product_key`,`device_id`) USING BTREE,
  KEY `idx_event_time` (`event`,`create_time`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin ROW_FORMAT=DYNAMIC COMMENT='设备日志分表20（按iotId哈希，内部分区）'
/*!50100 PARTITION BY RANGE (to_days(`create_time`))
(PARTITION p202509 VALUES LESS THAN (739890) ENGINE = InnoDB,
 PARTITION p202510 VALUES LESS THAN (739921) ENGINE = InnoDB,
 PARTITION p202511 VALUES LESS THAN (739951) ENGINE = InnoDB,
 PARTITION pmax VALUES LESS THAN MAXVALUE ENGINE = InnoDB) */;

-- ----------------------------
-- Records of iot_device_log_20
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for iot_device_log_21
-- ----------------------------
DROP TABLE IF EXISTS `iot_device_log_21`;
CREATE TABLE `iot_device_log_21` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `iot_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '设备唯一编码',
  `product_key` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '产品ID',
  `device_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '设备自身序号',
  `device_name` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '设备名称',
  `message_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '消息类型（EVENT/PROPERTIES/FUNCTIONS）',
  `command_id` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '指令ID',
  `command_status` tinyint DEFAULT '0' COMMENT '指令状态（0未执行/1成功/2失败）',
  `event` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '事件名称（如online/offline）',
  `point` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '经纬度（经度,纬度）',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin COMMENT '日志详情（JSON格式）',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间（无0值）',
  PRIMARY KEY (`id`,`create_time`) USING BTREE,
  KEY `idx_iot_id` (`iot_id`) USING BTREE,
  KEY `idx_product_device` (`product_key`,`device_id`) USING BTREE,
  KEY `idx_event_time` (`event`,`create_time`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin ROW_FORMAT=DYNAMIC COMMENT='设备日志分表21（按iotId哈希，内部分区）'
/*!50100 PARTITION BY RANGE (to_days(`create_time`))
(PARTITION p202509 VALUES LESS THAN (739890) ENGINE = InnoDB,
 PARTITION p202510 VALUES LESS THAN (739921) ENGINE = InnoDB,
 PARTITION p202511 VALUES LESS THAN (739951) ENGINE = InnoDB,
 PARTITION pmax VALUES LESS THAN MAXVALUE ENGINE = InnoDB) */;

-- ----------------------------
-- Records of iot_device_log_21
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for iot_device_log_22
-- ----------------------------
DROP TABLE IF EXISTS `iot_device_log_22`;
CREATE TABLE `iot_device_log_22` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `iot_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '设备唯一编码',
  `product_key` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '产品ID',
  `device_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '设备自身序号',
  `device_name` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '设备名称',
  `message_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '消息类型（EVENT/PROPERTIES/FUNCTIONS）',
  `command_id` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '指令ID',
  `command_status` tinyint DEFAULT '0' COMMENT '指令状态（0未执行/1成功/2失败）',
  `event` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '事件名称（如online/offline）',
  `point` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '经纬度（经度,纬度）',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin COMMENT '日志详情（JSON格式）',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间（无0值）',
  PRIMARY KEY (`id`,`create_time`) USING BTREE,
  KEY `idx_iot_id` (`iot_id`) USING BTREE,
  KEY `idx_product_device` (`product_key`,`device_id`) USING BTREE,
  KEY `idx_event_time` (`event`,`create_time`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin ROW_FORMAT=DYNAMIC COMMENT='设备日志分表22（按iotId哈希，内部分区）'
/*!50100 PARTITION BY RANGE (to_days(`create_time`))
(PARTITION p202509 VALUES LESS THAN (739890) ENGINE = InnoDB,
 PARTITION p202510 VALUES LESS THAN (739921) ENGINE = InnoDB,
 PARTITION p202511 VALUES LESS THAN (739951) ENGINE = InnoDB,
 PARTITION pmax VALUES LESS THAN MAXVALUE ENGINE = InnoDB) */;

-- ----------------------------
-- Records of iot_device_log_22
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for iot_device_log_23
-- ----------------------------
DROP TABLE IF EXISTS `iot_device_log_23`;
CREATE TABLE `iot_device_log_23` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `iot_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '设备唯一编码',
  `product_key` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '产品ID',
  `device_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '设备自身序号',
  `device_name` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '设备名称',
  `message_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '消息类型（EVENT/PROPERTIES/FUNCTIONS）',
  `command_id` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '指令ID',
  `command_status` tinyint DEFAULT '0' COMMENT '指令状态（0未执行/1成功/2失败）',
  `event` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '事件名称（如online/offline）',
  `point` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '经纬度（经度,纬度）',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin COMMENT '日志详情（JSON格式）',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间（无0值）',
  PRIMARY KEY (`id`,`create_time`) USING BTREE,
  KEY `idx_iot_id` (`iot_id`) USING BTREE,
  KEY `idx_product_device` (`product_key`,`device_id`) USING BTREE,
  KEY `idx_event_time` (`event`,`create_time`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin ROW_FORMAT=DYNAMIC COMMENT='设备日志分表23（按iotId哈希，内部分区）'
/*!50100 PARTITION BY RANGE (to_days(`create_time`))
(PARTITION p202509 VALUES LESS THAN (739890) ENGINE = InnoDB,
 PARTITION p202510 VALUES LESS THAN (739921) ENGINE = InnoDB,
 PARTITION p202511 VALUES LESS THAN (739951) ENGINE = InnoDB,
 PARTITION pmax VALUES LESS THAN MAXVALUE ENGINE = InnoDB) */;

-- ----------------------------
-- Records of iot_device_log_23
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for iot_device_log_3
-- ----------------------------
DROP TABLE IF EXISTS `iot_device_log_3`;
CREATE TABLE `iot_device_log_3` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `iot_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '设备唯一编码',
  `product_key` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '产品ID',
  `device_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '设备自身序号',
  `device_name` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '设备名称',
  `message_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '消息类型（EVENT/PROPERTIES/FUNCTIONS）',
  `command_id` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '指令ID',
  `command_status` tinyint DEFAULT '0' COMMENT '指令状态（0未执行/1成功/2失败）',
  `event` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '事件名称（如online/offline）',
  `point` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '经纬度（经度,纬度）',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin COMMENT '日志详情（JSON格式）',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间（无0值）',
  PRIMARY KEY (`id`,`create_time`) USING BTREE,
  KEY `idx_iot_id` (`iot_id`) USING BTREE,
  KEY `idx_product_device` (`product_key`,`device_id`) USING BTREE,
  KEY `idx_event_time` (`event`,`create_time`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=247 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin ROW_FORMAT=DYNAMIC COMMENT='设备日志分表3（按iotId哈希，内部分区）'
/*!50100 PARTITION BY RANGE (to_days(`create_time`))
(PARTITION p202509 VALUES LESS THAN (739890) ENGINE = InnoDB,
 PARTITION p202510 VALUES LESS THAN (739921) ENGINE = InnoDB,
 PARTITION p202511 VALUES LESS THAN (739951) ENGINE = InnoDB,
 PARTITION pmax VALUES LESS THAN MAXVALUE ENGINE = InnoDB) */;

-- ----------------------------
-- Records of iot_device_log_3
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for iot_device_log_4
-- ----------------------------
DROP TABLE IF EXISTS `iot_device_log_4`;
CREATE TABLE `iot_device_log_4` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `iot_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '设备唯一编码',
  `product_key` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '产品ID',
  `device_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '设备自身序号',
  `device_name` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '设备名称',
  `message_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '消息类型（EVENT/PROPERTIES/FUNCTIONS）',
  `command_id` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '指令ID',
  `command_status` tinyint DEFAULT '0' COMMENT '指令状态（0未执行/1成功/2失败）',
  `event` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '事件名称（如online/offline）',
  `point` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '经纬度（经度,纬度）',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin COMMENT '日志详情（JSON格式）',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间（无0值）',
  PRIMARY KEY (`id`,`create_time`) USING BTREE,
  KEY `idx_iot_id` (`iot_id`) USING BTREE,
  KEY `idx_product_device` (`product_key`,`device_id`) USING BTREE,
  KEY `idx_event_time` (`event`,`create_time`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=5331 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin ROW_FORMAT=DYNAMIC COMMENT='设备日志分表4（按iotId哈希，内部分区）'
/*!50100 PARTITION BY RANGE (to_days(`create_time`))
(PARTITION p202509 VALUES LESS THAN (739890) ENGINE = InnoDB,
 PARTITION p202510 VALUES LESS THAN (739921) ENGINE = InnoDB,
 PARTITION p202511 VALUES LESS THAN (739951) ENGINE = InnoDB,
 PARTITION pmax VALUES LESS THAN MAXVALUE ENGINE = InnoDB) */;

-- ----------------------------
-- Records of iot_device_log_4
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for iot_device_log_5
-- ----------------------------
DROP TABLE IF EXISTS `iot_device_log_5`;
CREATE TABLE `iot_device_log_5` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `iot_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '设备唯一编码',
  `product_key` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '产品ID',
  `device_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '设备自身序号',
  `device_name` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '设备名称',
  `message_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '消息类型（EVENT/PROPERTIES/FUNCTIONS）',
  `command_id` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '指令ID',
  `command_status` tinyint DEFAULT '0' COMMENT '指令状态（0未执行/1成功/2失败）',
  `event` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '事件名称（如online/offline）',
  `point` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '经纬度（经度,纬度）',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin COMMENT '日志详情（JSON格式）',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间（无0值）',
  PRIMARY KEY (`id`,`create_time`) USING BTREE,
  KEY `idx_iot_id` (`iot_id`) USING BTREE,
  KEY `idx_product_device` (`product_key`,`device_id`) USING BTREE,
  KEY `idx_event_time` (`event`,`create_time`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin ROW_FORMAT=DYNAMIC COMMENT='设备日志分表5（按iotId哈希，内部分区）'
/*!50100 PARTITION BY RANGE (to_days(`create_time`))
(PARTITION p202509 VALUES LESS THAN (739890) ENGINE = InnoDB,
 PARTITION p202510 VALUES LESS THAN (739921) ENGINE = InnoDB,
 PARTITION p202511 VALUES LESS THAN (739951) ENGINE = InnoDB,
 PARTITION pmax VALUES LESS THAN MAXVALUE ENGINE = InnoDB) */;

-- ----------------------------
-- Records of iot_device_log_5
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for iot_device_log_6
-- ----------------------------
DROP TABLE IF EXISTS `iot_device_log_6`;
CREATE TABLE `iot_device_log_6` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `iot_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '设备唯一编码',
  `product_key` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '产品ID',
  `device_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '设备自身序号',
  `device_name` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '设备名称',
  `message_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '消息类型（EVENT/PROPERTIES/FUNCTIONS）',
  `command_id` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '指令ID',
  `command_status` tinyint DEFAULT '0' COMMENT '指令状态（0未执行/1成功/2失败）',
  `event` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '事件名称（如online/offline）',
  `point` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '经纬度（经度,纬度）',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin COMMENT '日志详情（JSON格式）',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间（无0值）',
  PRIMARY KEY (`id`,`create_time`) USING BTREE,
  KEY `idx_iot_id` (`iot_id`) USING BTREE,
  KEY `idx_product_device` (`product_key`,`device_id`) USING BTREE,
  KEY `idx_event_time` (`event`,`create_time`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin ROW_FORMAT=DYNAMIC COMMENT='设备日志分表6（按iotId哈希，内部分区）'
/*!50100 PARTITION BY RANGE (to_days(`create_time`))
(PARTITION p202509 VALUES LESS THAN (739890) ENGINE = InnoDB,
 PARTITION p202510 VALUES LESS THAN (739921) ENGINE = InnoDB,
 PARTITION p202511 VALUES LESS THAN (739951) ENGINE = InnoDB,
 PARTITION pmax VALUES LESS THAN MAXVALUE ENGINE = InnoDB) */;

-- ----------------------------
-- Records of iot_device_log_6
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for iot_device_log_7
-- ----------------------------
DROP TABLE IF EXISTS `iot_device_log_7`;
CREATE TABLE `iot_device_log_7` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `iot_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '设备唯一编码',
  `product_key` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '产品ID',
  `device_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '设备自身序号',
  `device_name` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '设备名称',
  `message_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '消息类型（EVENT/PROPERTIES/FUNCTIONS）',
  `command_id` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '指令ID',
  `command_status` tinyint DEFAULT '0' COMMENT '指令状态（0未执行/1成功/2失败）',
  `event` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '事件名称（如online/offline）',
  `point` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '经纬度（经度,纬度）',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin COMMENT '日志详情（JSON格式）',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间（无0值）',
  PRIMARY KEY (`id`,`create_time`) USING BTREE,
  KEY `idx_iot_id` (`iot_id`) USING BTREE,
  KEY `idx_product_device` (`product_key`,`device_id`) USING BTREE,
  KEY `idx_event_time` (`event`,`create_time`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin ROW_FORMAT=DYNAMIC COMMENT='设备日志分表7（按iotId哈希，内部分区）'
/*!50100 PARTITION BY RANGE (to_days(`create_time`))
(PARTITION p202509 VALUES LESS THAN (739890) ENGINE = InnoDB,
 PARTITION p202510 VALUES LESS THAN (739921) ENGINE = InnoDB,
 PARTITION p202511 VALUES LESS THAN (739951) ENGINE = InnoDB,
 PARTITION pmax VALUES LESS THAN MAXVALUE ENGINE = InnoDB) */;

-- ----------------------------
-- Records of iot_device_log_7
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for iot_device_log_8
-- ----------------------------
DROP TABLE IF EXISTS `iot_device_log_8`;
CREATE TABLE `iot_device_log_8` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `iot_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '设备唯一编码',
  `product_key` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '产品ID',
  `device_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '设备自身序号',
  `device_name` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '设备名称',
  `message_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '消息类型（EVENT/PROPERTIES/FUNCTIONS）',
  `command_id` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '指令ID',
  `command_status` tinyint DEFAULT '0' COMMENT '指令状态（0未执行/1成功/2失败）',
  `event` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '事件名称（如online/offline）',
  `point` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '经纬度（经度,纬度）',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin COMMENT '日志详情（JSON格式）',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间（无0值）',
  PRIMARY KEY (`id`,`create_time`) USING BTREE,
  KEY `idx_iot_id` (`iot_id`) USING BTREE,
  KEY `idx_product_device` (`product_key`,`device_id`) USING BTREE,
  KEY `idx_event_time` (`event`,`create_time`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin ROW_FORMAT=DYNAMIC COMMENT='设备日志分表8（按iotId哈希，内部分区）'
/*!50100 PARTITION BY RANGE (to_days(`create_time`))
(PARTITION p202509 VALUES LESS THAN (739890) ENGINE = InnoDB,
 PARTITION p202510 VALUES LESS THAN (739921) ENGINE = InnoDB,
 PARTITION p202511 VALUES LESS THAN (739951) ENGINE = InnoDB,
 PARTITION pmax VALUES LESS THAN MAXVALUE ENGINE = InnoDB) */;

-- ----------------------------
-- Records of iot_device_log_8
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for iot_device_log_9
-- ----------------------------
DROP TABLE IF EXISTS `iot_device_log_9`;
CREATE TABLE `iot_device_log_9` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `iot_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '设备唯一编码',
  `product_key` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '产品ID',
  `device_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '设备自身序号',
  `device_name` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '设备名称',
  `message_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '消息类型（EVENT/PROPERTIES/FUNCTIONS）',
  `command_id` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '指令ID',
  `command_status` tinyint DEFAULT '0' COMMENT '指令状态（0未执行/1成功/2失败）',
  `event` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '事件名称（如online/offline）',
  `point` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '经纬度（经度,纬度）',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin COMMENT '日志详情（JSON格式）',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间（无0值）',
  PRIMARY KEY (`id`,`create_time`) USING BTREE,
  KEY `idx_iot_id` (`iot_id`) USING BTREE,
  KEY `idx_product_device` (`product_key`,`device_id`) USING BTREE,
  KEY `idx_event_time` (`event`,`create_time`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin ROW_FORMAT=DYNAMIC COMMENT='设备日志分表9（按iotId哈希，内部分区）'
/*!50100 PARTITION BY RANGE (to_days(`create_time`))
(PARTITION p202509 VALUES LESS THAN (739890) ENGINE = InnoDB,
 PARTITION p202510 VALUES LESS THAN (739921) ENGINE = InnoDB,
 PARTITION p202511 VALUES LESS THAN (739951) ENGINE = InnoDB,
 PARTITION pmax VALUES LESS THAN MAXVALUE ENGINE = InnoDB) */;

-- ----------------------------
-- Records of iot_device_log_9
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for iot_device_log_metadata
-- ----------------------------
DROP TABLE IF EXISTS `iot_device_log_metadata`;
CREATE TABLE `iot_device_log_metadata` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `iot_id` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `product_key` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '' COMMENT '产品唯一标识',
  `device_name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '设备名称',
  `device_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `message_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '消息类型',
  `event` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '',
  `property` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '属性',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin COMMENT '其他',
  `ext1` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '',
  `ext2` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '',
  `ext3` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '',
  `create_time` int DEFAULT '0' COMMENT '发生时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `idx_iot_Id` (`iot_id`) USING BTREE,
  KEY `idx_device_id` (`device_id`) USING BTREE,
  KEY `idx_create_time` (`create_time`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of iot_device_log_metadata
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for iot_device_log_metadata_0
-- ----------------------------
DROP TABLE IF EXISTS `iot_device_log_metadata_0`;
CREATE TABLE `iot_device_log_metadata_0` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `iot_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '设备唯一编码',
  `product_key` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '' COMMENT '产品ID',
  `device_name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '设备名称',
  `device_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '设备自身序号',
  `message_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '消息类型',
  `event` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '事件名称',
  `property` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '设备属性（如battery/csq）',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin COMMENT '元数据详情',
  `ext1` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '扩展字段1',
  `ext2` varchar(655) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '扩展字段2（长文本）',
  `ext3` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '扩展字段3',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间（无0值）',
  PRIMARY KEY (`id`,`create_time`) USING BTREE,
  KEY `idx_iot_id` (`iot_id`) USING BTREE,
  KEY `idx_product_device` (`product_key`,`device_id`) USING BTREE,
  KEY `idx_time_property` (`create_time`,`property`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin ROW_FORMAT=DYNAMIC COMMENT='设备日志元数据分表0（按iotId哈希，内部分区）'
/*!50100 PARTITION BY RANGE (to_days(`create_time`))
(PARTITION p202509 VALUES LESS THAN (739890) ENGINE = InnoDB,
 PARTITION p202510 VALUES LESS THAN (739921) ENGINE = InnoDB,
 PARTITION p202511 VALUES LESS THAN (739951) ENGINE = InnoDB,
 PARTITION pmax VALUES LESS THAN MAXVALUE ENGINE = InnoDB) */;

-- ----------------------------
-- Records of iot_device_log_metadata_0
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for iot_device_log_metadata_1
-- ----------------------------
DROP TABLE IF EXISTS `iot_device_log_metadata_1`;
CREATE TABLE `iot_device_log_metadata_1` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `iot_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '设备唯一编码',
  `product_key` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '' COMMENT '产品ID',
  `device_name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '设备名称',
  `device_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '设备自身序号',
  `message_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '消息类型',
  `event` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '事件名称',
  `property` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '设备属性（如battery/csq）',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin COMMENT '元数据详情',
  `ext1` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '扩展字段1',
  `ext2` varchar(655) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '扩展字段2（长文本）',
  `ext3` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '扩展字段3',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间（无0值）',
  PRIMARY KEY (`id`,`create_time`) USING BTREE,
  KEY `idx_iot_id` (`iot_id`) USING BTREE,
  KEY `idx_product_device` (`product_key`,`device_id`) USING BTREE,
  KEY `idx_time_property` (`create_time`,`property`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin ROW_FORMAT=DYNAMIC COMMENT='设备日志元数据分表1（按iotId哈希，内部分区）'
/*!50100 PARTITION BY RANGE (to_days(`create_time`))
(PARTITION p202509 VALUES LESS THAN (739890) ENGINE = InnoDB,
 PARTITION p202510 VALUES LESS THAN (739921) ENGINE = InnoDB,
 PARTITION p202511 VALUES LESS THAN (739951) ENGINE = InnoDB,
 PARTITION pmax VALUES LESS THAN MAXVALUE ENGINE = InnoDB) */;

-- ----------------------------
-- Records of iot_device_log_metadata_1
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for iot_device_log_metadata_10
-- ----------------------------
DROP TABLE IF EXISTS `iot_device_log_metadata_10`;
CREATE TABLE `iot_device_log_metadata_10` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `iot_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '设备唯一编码',
  `product_key` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '' COMMENT '产品ID',
  `device_name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '设备名称',
  `device_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '设备自身序号',
  `message_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '消息类型',
  `event` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '事件名称',
  `property` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '设备属性（如battery/csq）',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin COMMENT '元数据详情',
  `ext1` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '扩展字段1',
  `ext2` varchar(655) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '扩展字段2（长文本）',
  `ext3` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '扩展字段3',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间（无0值）',
  PRIMARY KEY (`id`,`create_time`) USING BTREE,
  KEY `idx_iot_id` (`iot_id`) USING BTREE,
  KEY `idx_product_device` (`product_key`,`device_id`) USING BTREE,
  KEY `idx_time_property` (`create_time`,`property`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin ROW_FORMAT=DYNAMIC COMMENT='设备日志元数据分表10（按iotId哈希，内部分区）'
/*!50100 PARTITION BY RANGE (to_days(`create_time`))
(PARTITION p202509 VALUES LESS THAN (739890) ENGINE = InnoDB,
 PARTITION p202510 VALUES LESS THAN (739921) ENGINE = InnoDB,
 PARTITION p202511 VALUES LESS THAN (739951) ENGINE = InnoDB,
 PARTITION pmax VALUES LESS THAN MAXVALUE ENGINE = InnoDB) */;

-- ----------------------------
-- Records of iot_device_log_metadata_10
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for iot_device_log_metadata_11
-- ----------------------------
DROP TABLE IF EXISTS `iot_device_log_metadata_11`;
CREATE TABLE `iot_device_log_metadata_11` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `iot_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '设备唯一编码',
  `product_key` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '' COMMENT '产品ID',
  `device_name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '设备名称',
  `device_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '设备自身序号',
  `message_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '消息类型',
  `event` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '事件名称',
  `property` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '设备属性（如battery/csq）',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin COMMENT '元数据详情',
  `ext1` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '扩展字段1',
  `ext2` varchar(655) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '扩展字段2（长文本）',
  `ext3` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '扩展字段3',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间（无0值）',
  PRIMARY KEY (`id`,`create_time`) USING BTREE,
  KEY `idx_iot_id` (`iot_id`) USING BTREE,
  KEY `idx_product_device` (`product_key`,`device_id`) USING BTREE,
  KEY `idx_time_property` (`create_time`,`property`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=21421 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin ROW_FORMAT=DYNAMIC COMMENT='设备日志元数据分表11（按iotId哈希，内部分区）'
/*!50100 PARTITION BY RANGE (to_days(`create_time`))
(PARTITION p202509 VALUES LESS THAN (739890) ENGINE = InnoDB,
 PARTITION p202510 VALUES LESS THAN (739921) ENGINE = InnoDB,
 PARTITION p202511 VALUES LESS THAN (739951) ENGINE = InnoDB,
 PARTITION pmax VALUES LESS THAN MAXVALUE ENGINE = InnoDB) */;

-- ----------------------------
-- Records of iot_device_log_metadata_11
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for iot_device_log_metadata_12
-- ----------------------------
DROP TABLE IF EXISTS `iot_device_log_metadata_12`;
CREATE TABLE `iot_device_log_metadata_12` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `iot_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '设备唯一编码',
  `product_key` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '' COMMENT '产品ID',
  `device_name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '设备名称',
  `device_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '设备自身序号',
  `message_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '消息类型',
  `event` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '事件名称',
  `property` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '设备属性（如battery/csq）',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin COMMENT '元数据详情',
  `ext1` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '扩展字段1',
  `ext2` varchar(655) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '扩展字段2（长文本）',
  `ext3` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '扩展字段3',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间（无0值）',
  PRIMARY KEY (`id`,`create_time`) USING BTREE,
  KEY `idx_iot_id` (`iot_id`) USING BTREE,
  KEY `idx_product_device` (`product_key`,`device_id`) USING BTREE,
  KEY `idx_time_property` (`create_time`,`property`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin ROW_FORMAT=DYNAMIC COMMENT='设备日志元数据分表12（按iotId哈希，内部分区）'
/*!50100 PARTITION BY RANGE (to_days(`create_time`))
(PARTITION p202509 VALUES LESS THAN (739890) ENGINE = InnoDB,
 PARTITION p202510 VALUES LESS THAN (739921) ENGINE = InnoDB,
 PARTITION p202511 VALUES LESS THAN (739951) ENGINE = InnoDB,
 PARTITION pmax VALUES LESS THAN MAXVALUE ENGINE = InnoDB) */;

-- ----------------------------
-- Records of iot_device_log_metadata_12
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for iot_device_log_metadata_13
-- ----------------------------
DROP TABLE IF EXISTS `iot_device_log_metadata_13`;
CREATE TABLE `iot_device_log_metadata_13` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `iot_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '设备唯一编码',
  `product_key` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '' COMMENT '产品ID',
  `device_name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '设备名称',
  `device_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '设备自身序号',
  `message_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '消息类型',
  `event` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '事件名称',
  `property` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '设备属性（如battery/csq）',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin COMMENT '元数据详情',
  `ext1` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '扩展字段1',
  `ext2` varchar(655) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '扩展字段2（长文本）',
  `ext3` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '扩展字段3',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间（无0值）',
  PRIMARY KEY (`id`,`create_time`) USING BTREE,
  KEY `idx_iot_id` (`iot_id`) USING BTREE,
  KEY `idx_product_device` (`product_key`,`device_id`) USING BTREE,
  KEY `idx_time_property` (`create_time`,`property`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=14737 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin ROW_FORMAT=DYNAMIC COMMENT='设备日志元数据分表13（按iotId哈希，内部分区）'
/*!50100 PARTITION BY RANGE (to_days(`create_time`))
(PARTITION p202509 VALUES LESS THAN (739890) ENGINE = InnoDB,
 PARTITION p202510 VALUES LESS THAN (739921) ENGINE = InnoDB,
 PARTITION p202511 VALUES LESS THAN (739951) ENGINE = InnoDB,
 PARTITION pmax VALUES LESS THAN MAXVALUE ENGINE = InnoDB) */;

-- ----------------------------
-- Records of iot_device_log_metadata_13
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for iot_device_log_metadata_14
-- ----------------------------
DROP TABLE IF EXISTS `iot_device_log_metadata_14`;
CREATE TABLE `iot_device_log_metadata_14` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `iot_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '设备唯一编码',
  `product_key` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '' COMMENT '产品ID',
  `device_name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '设备名称',
  `device_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '设备自身序号',
  `message_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '消息类型',
  `event` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '事件名称',
  `property` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '设备属性（如battery/csq）',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin COMMENT '元数据详情',
  `ext1` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '扩展字段1',
  `ext2` varchar(655) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '扩展字段2（长文本）',
  `ext3` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '扩展字段3',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间（无0值）',
  PRIMARY KEY (`id`,`create_time`) USING BTREE,
  KEY `idx_iot_id` (`iot_id`) USING BTREE,
  KEY `idx_product_device` (`product_key`,`device_id`) USING BTREE,
  KEY `idx_time_property` (`create_time`,`property`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin ROW_FORMAT=DYNAMIC COMMENT='设备日志元数据分表14（按iotId哈希，内部分区）'
/*!50100 PARTITION BY RANGE (to_days(`create_time`))
(PARTITION p202509 VALUES LESS THAN (739890) ENGINE = InnoDB,
 PARTITION p202510 VALUES LESS THAN (739921) ENGINE = InnoDB,
 PARTITION p202511 VALUES LESS THAN (739951) ENGINE = InnoDB,
 PARTITION pmax VALUES LESS THAN MAXVALUE ENGINE = InnoDB) */;

-- ----------------------------
-- Records of iot_device_log_metadata_14
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for iot_device_log_metadata_15
-- ----------------------------
DROP TABLE IF EXISTS `iot_device_log_metadata_15`;
CREATE TABLE `iot_device_log_metadata_15` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `iot_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '设备唯一编码',
  `product_key` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '' COMMENT '产品ID',
  `device_name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '设备名称',
  `device_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '设备自身序号',
  `message_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '消息类型',
  `event` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '事件名称',
  `property` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '设备属性（如battery/csq）',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin COMMENT '元数据详情',
  `ext1` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '扩展字段1',
  `ext2` varchar(655) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '扩展字段2（长文本）',
  `ext3` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '扩展字段3',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间（无0值）',
  PRIMARY KEY (`id`,`create_time`) USING BTREE,
  KEY `idx_iot_id` (`iot_id`) USING BTREE,
  KEY `idx_product_device` (`product_key`,`device_id`) USING BTREE,
  KEY `idx_time_property` (`create_time`,`property`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1780 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin ROW_FORMAT=DYNAMIC COMMENT='设备日志元数据分表15（按iotId哈希，内部分区）'
/*!50100 PARTITION BY RANGE (to_days(`create_time`))
(PARTITION p202509 VALUES LESS THAN (739890) ENGINE = InnoDB,
 PARTITION p202510 VALUES LESS THAN (739921) ENGINE = InnoDB,
 PARTITION p202511 VALUES LESS THAN (739951) ENGINE = InnoDB,
 PARTITION pmax VALUES LESS THAN MAXVALUE ENGINE = InnoDB) */;

-- ----------------------------
-- Records of iot_device_log_metadata_15
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for iot_device_log_metadata_16
-- ----------------------------
DROP TABLE IF EXISTS `iot_device_log_metadata_16`;
CREATE TABLE `iot_device_log_metadata_16` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `iot_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '设备唯一编码',
  `product_key` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '' COMMENT '产品ID',
  `device_name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '设备名称',
  `device_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '设备自身序号',
  `message_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '消息类型',
  `event` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '事件名称',
  `property` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '设备属性（如battery/csq）',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin COMMENT '元数据详情',
  `ext1` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '扩展字段1',
  `ext2` varchar(655) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '扩展字段2（长文本）',
  `ext3` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '扩展字段3',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间（无0值）',
  PRIMARY KEY (`id`,`create_time`) USING BTREE,
  KEY `idx_iot_id` (`iot_id`) USING BTREE,
  KEY `idx_product_device` (`product_key`,`device_id`) USING BTREE,
  KEY `idx_time_property` (`create_time`,`property`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin ROW_FORMAT=DYNAMIC COMMENT='设备日志元数据分表16（按iotId哈希，内部分区）'
/*!50100 PARTITION BY RANGE (to_days(`create_time`))
(PARTITION p202509 VALUES LESS THAN (739890) ENGINE = InnoDB,
 PARTITION p202510 VALUES LESS THAN (739921) ENGINE = InnoDB,
 PARTITION p202511 VALUES LESS THAN (739951) ENGINE = InnoDB,
 PARTITION pmax VALUES LESS THAN MAXVALUE ENGINE = InnoDB) */;

-- ----------------------------
-- Records of iot_device_log_metadata_16
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for iot_device_log_metadata_17
-- ----------------------------
DROP TABLE IF EXISTS `iot_device_log_metadata_17`;
CREATE TABLE `iot_device_log_metadata_17` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `iot_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '设备唯一编码',
  `product_key` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '' COMMENT '产品ID',
  `device_name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '设备名称',
  `device_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '设备自身序号',
  `message_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '消息类型',
  `event` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '事件名称',
  `property` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '设备属性（如battery/csq）',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin COMMENT '元数据详情',
  `ext1` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '扩展字段1',
  `ext2` varchar(655) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '扩展字段2（长文本）',
  `ext3` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '扩展字段3',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间（无0值）',
  PRIMARY KEY (`id`,`create_time`) USING BTREE,
  KEY `idx_iot_id` (`iot_id`) USING BTREE,
  KEY `idx_product_device` (`product_key`,`device_id`) USING BTREE,
  KEY `idx_time_property` (`create_time`,`property`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin ROW_FORMAT=DYNAMIC COMMENT='设备日志元数据分表17（按iotId哈希，内部分区）'
/*!50100 PARTITION BY RANGE (to_days(`create_time`))
(PARTITION p202509 VALUES LESS THAN (739890) ENGINE = InnoDB,
 PARTITION p202510 VALUES LESS THAN (739921) ENGINE = InnoDB,
 PARTITION p202511 VALUES LESS THAN (739951) ENGINE = InnoDB,
 PARTITION pmax VALUES LESS THAN MAXVALUE ENGINE = InnoDB) */;

-- ----------------------------
-- Records of iot_device_log_metadata_17
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for iot_device_log_metadata_18
-- ----------------------------
DROP TABLE IF EXISTS `iot_device_log_metadata_18`;
CREATE TABLE `iot_device_log_metadata_18` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `iot_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '设备唯一编码',
  `product_key` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '' COMMENT '产品ID',
  `device_name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '设备名称',
  `device_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '设备自身序号',
  `message_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '消息类型',
  `event` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '事件名称',
  `property` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '设备属性（如battery/csq）',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin COMMENT '元数据详情',
  `ext1` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '扩展字段1',
  `ext2` varchar(655) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '扩展字段2（长文本）',
  `ext3` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '扩展字段3',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间（无0值）',
  PRIMARY KEY (`id`,`create_time`) USING BTREE,
  KEY `idx_iot_id` (`iot_id`) USING BTREE,
  KEY `idx_product_device` (`product_key`,`device_id`) USING BTREE,
  KEY `idx_time_property` (`create_time`,`property`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3346 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin ROW_FORMAT=DYNAMIC COMMENT='设备日志元数据分表18（按iotId哈希，内部分区）'
/*!50100 PARTITION BY RANGE (to_days(`create_time`))
(PARTITION p202509 VALUES LESS THAN (739890) ENGINE = InnoDB,
 PARTITION p202510 VALUES LESS THAN (739921) ENGINE = InnoDB,
 PARTITION p202511 VALUES LESS THAN (739951) ENGINE = InnoDB,
 PARTITION pmax VALUES LESS THAN MAXVALUE ENGINE = InnoDB) */;

-- ----------------------------
-- Records of iot_device_log_metadata_18
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for iot_device_log_metadata_19
-- ----------------------------
DROP TABLE IF EXISTS `iot_device_log_metadata_19`;
CREATE TABLE `iot_device_log_metadata_19` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `iot_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '设备唯一编码',
  `product_key` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '' COMMENT '产品ID',
  `device_name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '设备名称',
  `device_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '设备自身序号',
  `message_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '消息类型',
  `event` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '事件名称',
  `property` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '设备属性（如battery/csq）',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin COMMENT '元数据详情',
  `ext1` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '扩展字段1',
  `ext2` varchar(655) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '扩展字段2（长文本）',
  `ext3` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '扩展字段3',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间（无0值）',
  PRIMARY KEY (`id`,`create_time`) USING BTREE,
  KEY `idx_iot_id` (`iot_id`) USING BTREE,
  KEY `idx_product_device` (`product_key`,`device_id`) USING BTREE,
  KEY `idx_time_property` (`create_time`,`property`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin ROW_FORMAT=DYNAMIC COMMENT='设备日志元数据分表19（按iotId哈希，内部分区）'
/*!50100 PARTITION BY RANGE (to_days(`create_time`))
(PARTITION p202509 VALUES LESS THAN (739890) ENGINE = InnoDB,
 PARTITION p202510 VALUES LESS THAN (739921) ENGINE = InnoDB,
 PARTITION p202511 VALUES LESS THAN (739951) ENGINE = InnoDB,
 PARTITION pmax VALUES LESS THAN MAXVALUE ENGINE = InnoDB) */;

-- ----------------------------
-- Records of iot_device_log_metadata_19
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for iot_device_log_metadata_2
-- ----------------------------
DROP TABLE IF EXISTS `iot_device_log_metadata_2`;
CREATE TABLE `iot_device_log_metadata_2` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `iot_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '设备唯一编码',
  `product_key` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '' COMMENT '产品ID',
  `device_name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '设备名称',
  `device_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '设备自身序号',
  `message_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '消息类型',
  `event` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '事件名称',
  `property` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '设备属性（如battery/csq）',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin COMMENT '元数据详情',
  `ext1` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '扩展字段1',
  `ext2` varchar(655) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '扩展字段2（长文本）',
  `ext3` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '扩展字段3',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间（无0值）',
  PRIMARY KEY (`id`,`create_time`) USING BTREE,
  KEY `idx_iot_id` (`iot_id`) USING BTREE,
  KEY `idx_product_device` (`product_key`,`device_id`) USING BTREE,
  KEY `idx_time_property` (`create_time`,`property`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin ROW_FORMAT=DYNAMIC COMMENT='设备日志元数据分表2（按iotId哈希，内部分区）'
/*!50100 PARTITION BY RANGE (to_days(`create_time`))
(PARTITION p202509 VALUES LESS THAN (739890) ENGINE = InnoDB,
 PARTITION p202510 VALUES LESS THAN (739921) ENGINE = InnoDB,
 PARTITION p202511 VALUES LESS THAN (739951) ENGINE = InnoDB,
 PARTITION pmax VALUES LESS THAN MAXVALUE ENGINE = InnoDB) */;

-- ----------------------------
-- Records of iot_device_log_metadata_2
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for iot_device_log_metadata_20
-- ----------------------------
DROP TABLE IF EXISTS `iot_device_log_metadata_20`;
CREATE TABLE `iot_device_log_metadata_20` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `iot_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '设备唯一编码',
  `product_key` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '' COMMENT '产品ID',
  `device_name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '设备名称',
  `device_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '设备自身序号',
  `message_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '消息类型',
  `event` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '事件名称',
  `property` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '设备属性（如battery/csq）',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin COMMENT '元数据详情',
  `ext1` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '扩展字段1',
  `ext2` varchar(655) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '扩展字段2（长文本）',
  `ext3` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '扩展字段3',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间（无0值）',
  PRIMARY KEY (`id`,`create_time`) USING BTREE,
  KEY `idx_iot_id` (`iot_id`) USING BTREE,
  KEY `idx_product_device` (`product_key`,`device_id`) USING BTREE,
  KEY `idx_time_property` (`create_time`,`property`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin ROW_FORMAT=DYNAMIC COMMENT='设备日志元数据分表20（按iotId哈希，内部分区）'
/*!50100 PARTITION BY RANGE (to_days(`create_time`))
(PARTITION p202509 VALUES LESS THAN (739890) ENGINE = InnoDB,
 PARTITION p202510 VALUES LESS THAN (739921) ENGINE = InnoDB,
 PARTITION p202511 VALUES LESS THAN (739951) ENGINE = InnoDB,
 PARTITION pmax VALUES LESS THAN MAXVALUE ENGINE = InnoDB) */;

-- ----------------------------
-- Records of iot_device_log_metadata_20
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for iot_device_log_metadata_21
-- ----------------------------
DROP TABLE IF EXISTS `iot_device_log_metadata_21`;
CREATE TABLE `iot_device_log_metadata_21` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `iot_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '设备唯一编码',
  `product_key` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '' COMMENT '产品ID',
  `device_name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '设备名称',
  `device_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '设备自身序号',
  `message_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '消息类型',
  `event` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '事件名称',
  `property` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '设备属性（如battery/csq）',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin COMMENT '元数据详情',
  `ext1` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '扩展字段1',
  `ext2` varchar(655) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '扩展字段2（长文本）',
  `ext3` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '扩展字段3',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间（无0值）',
  PRIMARY KEY (`id`,`create_time`) USING BTREE,
  KEY `idx_iot_id` (`iot_id`) USING BTREE,
  KEY `idx_product_device` (`product_key`,`device_id`) USING BTREE,
  KEY `idx_time_property` (`create_time`,`property`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin ROW_FORMAT=DYNAMIC COMMENT='设备日志元数据分表21（按iotId哈希，内部分区）'
/*!50100 PARTITION BY RANGE (to_days(`create_time`))
(PARTITION p202509 VALUES LESS THAN (739890) ENGINE = InnoDB,
 PARTITION p202510 VALUES LESS THAN (739921) ENGINE = InnoDB,
 PARTITION p202511 VALUES LESS THAN (739951) ENGINE = InnoDB,
 PARTITION pmax VALUES LESS THAN MAXVALUE ENGINE = InnoDB) */;

-- ----------------------------
-- Records of iot_device_log_metadata_21
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for iot_device_log_metadata_22
-- ----------------------------
DROP TABLE IF EXISTS `iot_device_log_metadata_22`;
CREATE TABLE `iot_device_log_metadata_22` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `iot_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '设备唯一编码',
  `product_key` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '' COMMENT '产品ID',
  `device_name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '设备名称',
  `device_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '设备自身序号',
  `message_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '消息类型',
  `event` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '事件名称',
  `property` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '设备属性（如battery/csq）',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin COMMENT '元数据详情',
  `ext1` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '扩展字段1',
  `ext2` varchar(655) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '扩展字段2（长文本）',
  `ext3` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '扩展字段3',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间（无0值）',
  PRIMARY KEY (`id`,`create_time`) USING BTREE,
  KEY `idx_iot_id` (`iot_id`) USING BTREE,
  KEY `idx_product_device` (`product_key`,`device_id`) USING BTREE,
  KEY `idx_time_property` (`create_time`,`property`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin ROW_FORMAT=DYNAMIC COMMENT='设备日志元数据分表22（按iotId哈希，内部分区）'
/*!50100 PARTITION BY RANGE (to_days(`create_time`))
(PARTITION p202509 VALUES LESS THAN (739890) ENGINE = InnoDB,
 PARTITION p202510 VALUES LESS THAN (739921) ENGINE = InnoDB,
 PARTITION p202511 VALUES LESS THAN (739951) ENGINE = InnoDB,
 PARTITION pmax VALUES LESS THAN MAXVALUE ENGINE = InnoDB) */;

-- ----------------------------
-- Records of iot_device_log_metadata_22
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for iot_device_log_metadata_23
-- ----------------------------
DROP TABLE IF EXISTS `iot_device_log_metadata_23`;
CREATE TABLE `iot_device_log_metadata_23` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `iot_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '设备唯一编码',
  `product_key` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '' COMMENT '产品ID',
  `device_name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '设备名称',
  `device_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '设备自身序号',
  `message_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '消息类型',
  `event` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '事件名称',
  `property` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '设备属性（如battery/csq）',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin COMMENT '元数据详情',
  `ext1` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '扩展字段1',
  `ext2` varchar(655) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '扩展字段2（长文本）',
  `ext3` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '扩展字段3',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间（无0值）',
  PRIMARY KEY (`id`,`create_time`) USING BTREE,
  KEY `idx_iot_id` (`iot_id`) USING BTREE,
  KEY `idx_product_device` (`product_key`,`device_id`) USING BTREE,
  KEY `idx_time_property` (`create_time`,`property`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin ROW_FORMAT=DYNAMIC COMMENT='设备日志元数据分表23（按iotId哈希，内部分区）'
/*!50100 PARTITION BY RANGE (to_days(`create_time`))
(PARTITION p202509 VALUES LESS THAN (739890) ENGINE = InnoDB,
 PARTITION p202510 VALUES LESS THAN (739921) ENGINE = InnoDB,
 PARTITION p202511 VALUES LESS THAN (739951) ENGINE = InnoDB,
 PARTITION pmax VALUES LESS THAN MAXVALUE ENGINE = InnoDB) */;

-- ----------------------------
-- Records of iot_device_log_metadata_23
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for iot_device_log_metadata_3
-- ----------------------------
DROP TABLE IF EXISTS `iot_device_log_metadata_3`;
CREATE TABLE `iot_device_log_metadata_3` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `iot_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '设备唯一编码',
  `product_key` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '' COMMENT '产品ID',
  `device_name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '设备名称',
  `device_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '设备自身序号',
  `message_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '消息类型',
  `event` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '事件名称',
  `property` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '设备属性（如battery/csq）',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin COMMENT '元数据详情',
  `ext1` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '扩展字段1',
  `ext2` varchar(655) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '扩展字段2（长文本）',
  `ext3` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '扩展字段3',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间（无0值）',
  PRIMARY KEY (`id`,`create_time`) USING BTREE,
  KEY `idx_iot_id` (`iot_id`) USING BTREE,
  KEY `idx_product_device` (`product_key`,`device_id`) USING BTREE,
  KEY `idx_time_property` (`create_time`,`property`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin ROW_FORMAT=DYNAMIC COMMENT='设备日志元数据分表3（按iotId哈希，内部分区）'
/*!50100 PARTITION BY RANGE (to_days(`create_time`))
(PARTITION p202509 VALUES LESS THAN (739890) ENGINE = InnoDB,
 PARTITION p202510 VALUES LESS THAN (739921) ENGINE = InnoDB,
 PARTITION p202511 VALUES LESS THAN (739951) ENGINE = InnoDB,
 PARTITION pmax VALUES LESS THAN MAXVALUE ENGINE = InnoDB) */;

-- ----------------------------
-- Records of iot_device_log_metadata_3
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for iot_device_log_metadata_4
-- ----------------------------
DROP TABLE IF EXISTS `iot_device_log_metadata_4`;
CREATE TABLE `iot_device_log_metadata_4` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `iot_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '设备唯一编码',
  `product_key` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '' COMMENT '产品ID',
  `device_name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '设备名称',
  `device_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '设备自身序号',
  `message_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '消息类型',
  `event` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '事件名称',
  `property` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '设备属性（如battery/csq）',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin COMMENT '元数据详情',
  `ext1` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '扩展字段1',
  `ext2` varchar(655) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '扩展字段2（长文本）',
  `ext3` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '扩展字段3',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间（无0值）',
  PRIMARY KEY (`id`,`create_time`) USING BTREE,
  KEY `idx_iot_id` (`iot_id`) USING BTREE,
  KEY `idx_product_device` (`product_key`,`device_id`) USING BTREE,
  KEY `idx_time_property` (`create_time`,`property`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=15991 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin ROW_FORMAT=DYNAMIC COMMENT='设备日志元数据分表4（按iotId哈希，内部分区）'
/*!50100 PARTITION BY RANGE (to_days(`create_time`))
(PARTITION p202509 VALUES LESS THAN (739890) ENGINE = InnoDB,
 PARTITION p202510 VALUES LESS THAN (739921) ENGINE = InnoDB,
 PARTITION p202511 VALUES LESS THAN (739951) ENGINE = InnoDB,
 PARTITION pmax VALUES LESS THAN MAXVALUE ENGINE = InnoDB) */;

-- ----------------------------
-- Records of iot_device_log_metadata_4
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for iot_device_log_metadata_5
-- ----------------------------
DROP TABLE IF EXISTS `iot_device_log_metadata_5`;
CREATE TABLE `iot_device_log_metadata_5` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `iot_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '设备唯一编码',
  `product_key` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '' COMMENT '产品ID',
  `device_name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '设备名称',
  `device_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '设备自身序号',
  `message_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '消息类型',
  `event` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '事件名称',
  `property` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '设备属性（如battery/csq）',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin COMMENT '元数据详情',
  `ext1` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '扩展字段1',
  `ext2` varchar(655) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '扩展字段2（长文本）',
  `ext3` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '扩展字段3',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间（无0值）',
  PRIMARY KEY (`id`,`create_time`) USING BTREE,
  KEY `idx_iot_id` (`iot_id`) USING BTREE,
  KEY `idx_product_device` (`product_key`,`device_id`) USING BTREE,
  KEY `idx_time_property` (`create_time`,`property`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin ROW_FORMAT=DYNAMIC COMMENT='设备日志元数据分表5（按iotId哈希，内部分区）'
/*!50100 PARTITION BY RANGE (to_days(`create_time`))
(PARTITION p202509 VALUES LESS THAN (739890) ENGINE = InnoDB,
 PARTITION p202510 VALUES LESS THAN (739921) ENGINE = InnoDB,
 PARTITION p202511 VALUES LESS THAN (739951) ENGINE = InnoDB,
 PARTITION pmax VALUES LESS THAN MAXVALUE ENGINE = InnoDB) */;

-- ----------------------------
-- Records of iot_device_log_metadata_5
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for iot_device_log_metadata_6
-- ----------------------------
DROP TABLE IF EXISTS `iot_device_log_metadata_6`;
CREATE TABLE `iot_device_log_metadata_6` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `iot_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '设备唯一编码',
  `product_key` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '' COMMENT '产品ID',
  `device_name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '设备名称',
  `device_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '设备自身序号',
  `message_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '消息类型',
  `event` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '事件名称',
  `property` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '设备属性（如battery/csq）',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin COMMENT '元数据详情',
  `ext1` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '扩展字段1',
  `ext2` varchar(655) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '扩展字段2（长文本）',
  `ext3` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '扩展字段3',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间（无0值）',
  PRIMARY KEY (`id`,`create_time`) USING BTREE,
  KEY `idx_iot_id` (`iot_id`) USING BTREE,
  KEY `idx_product_device` (`product_key`,`device_id`) USING BTREE,
  KEY `idx_time_property` (`create_time`,`property`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin ROW_FORMAT=DYNAMIC COMMENT='设备日志元数据分表6（按iotId哈希，内部分区）'
/*!50100 PARTITION BY RANGE (to_days(`create_time`))
(PARTITION p202509 VALUES LESS THAN (739890) ENGINE = InnoDB,
 PARTITION p202510 VALUES LESS THAN (739921) ENGINE = InnoDB,
 PARTITION p202511 VALUES LESS THAN (739951) ENGINE = InnoDB,
 PARTITION pmax VALUES LESS THAN MAXVALUE ENGINE = InnoDB) */;

-- ----------------------------
-- Records of iot_device_log_metadata_6
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for iot_device_log_metadata_7
-- ----------------------------
DROP TABLE IF EXISTS `iot_device_log_metadata_7`;
CREATE TABLE `iot_device_log_metadata_7` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `iot_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '设备唯一编码',
  `product_key` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '' COMMENT '产品ID',
  `device_name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '设备名称',
  `device_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '设备自身序号',
  `message_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '消息类型',
  `event` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '事件名称',
  `property` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '设备属性（如battery/csq）',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin COMMENT '元数据详情',
  `ext1` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '扩展字段1',
  `ext2` varchar(655) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '扩展字段2（长文本）',
  `ext3` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '扩展字段3',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间（无0值）',
  PRIMARY KEY (`id`,`create_time`) USING BTREE,
  KEY `idx_iot_id` (`iot_id`) USING BTREE,
  KEY `idx_product_device` (`product_key`,`device_id`) USING BTREE,
  KEY `idx_time_property` (`create_time`,`property`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin ROW_FORMAT=DYNAMIC COMMENT='设备日志元数据分表7（按iotId哈希，内部分区）'
/*!50100 PARTITION BY RANGE (to_days(`create_time`))
(PARTITION p202509 VALUES LESS THAN (739890) ENGINE = InnoDB,
 PARTITION p202510 VALUES LESS THAN (739921) ENGINE = InnoDB,
 PARTITION p202511 VALUES LESS THAN (739951) ENGINE = InnoDB,
 PARTITION pmax VALUES LESS THAN MAXVALUE ENGINE = InnoDB) */;

-- ----------------------------
-- Records of iot_device_log_metadata_7
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for iot_device_log_metadata_8
-- ----------------------------
DROP TABLE IF EXISTS `iot_device_log_metadata_8`;
CREATE TABLE `iot_device_log_metadata_8` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `iot_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '设备唯一编码',
  `product_key` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '' COMMENT '产品ID',
  `device_name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '设备名称',
  `device_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '设备自身序号',
  `message_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '消息类型',
  `event` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '事件名称',
  `property` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '设备属性（如battery/csq）',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin COMMENT '元数据详情',
  `ext1` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '扩展字段1',
  `ext2` varchar(655) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '扩展字段2（长文本）',
  `ext3` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '扩展字段3',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间（无0值）',
  PRIMARY KEY (`id`,`create_time`) USING BTREE,
  KEY `idx_iot_id` (`iot_id`) USING BTREE,
  KEY `idx_product_device` (`product_key`,`device_id`) USING BTREE,
  KEY `idx_time_property` (`create_time`,`property`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin ROW_FORMAT=DYNAMIC COMMENT='设备日志元数据分表8（按iotId哈希，内部分区）'
/*!50100 PARTITION BY RANGE (to_days(`create_time`))
(PARTITION p202509 VALUES LESS THAN (739890) ENGINE = InnoDB,
 PARTITION p202510 VALUES LESS THAN (739921) ENGINE = InnoDB,
 PARTITION p202511 VALUES LESS THAN (739951) ENGINE = InnoDB,
 PARTITION pmax VALUES LESS THAN MAXVALUE ENGINE = InnoDB) */;

-- ----------------------------
-- Records of iot_device_log_metadata_8
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for iot_device_log_metadata_9
-- ----------------------------
DROP TABLE IF EXISTS `iot_device_log_metadata_9`;
CREATE TABLE `iot_device_log_metadata_9` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `iot_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '设备唯一编码',
  `product_key` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '' COMMENT '产品ID',
  `device_name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '设备名称',
  `device_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '设备自身序号',
  `message_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '消息类型',
  `event` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '事件名称',
  `property` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '设备属性（如battery/csq）',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin COMMENT '元数据详情',
  `ext1` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '扩展字段1',
  `ext2` varchar(655) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '扩展字段2（长文本）',
  `ext3` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '扩展字段3',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间（无0值）',
  PRIMARY KEY (`id`,`create_time`) USING BTREE,
  KEY `idx_iot_id` (`iot_id`) USING BTREE,
  KEY `idx_product_device` (`product_key`,`device_id`) USING BTREE,
  KEY `idx_time_property` (`create_time`,`property`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin ROW_FORMAT=DYNAMIC COMMENT='设备日志元数据分表9（按iotId哈希，内部分区）'
/*!50100 PARTITION BY RANGE (to_days(`create_time`))
(PARTITION p202509 VALUES LESS THAN (739890) ENGINE = InnoDB,
 PARTITION p202510 VALUES LESS THAN (739921) ENGINE = InnoDB,
 PARTITION p202511 VALUES LESS THAN (739951) ENGINE = InnoDB,
 PARTITION pmax VALUES LESS THAN MAXVALUE ENGINE = InnoDB) */;

-- ----------------------------
-- Records of iot_device_log_metadata_9
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for iot_device_model
-- ----------------------------
DROP TABLE IF EXISTS `iot_device_model`;
CREATE TABLE `iot_device_model` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'id',
  `product_key` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT '' COMMENT '产品编号',
  `company_no` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT '' COMMENT '厂家编号',
  `company_name` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT '' COMMENT '厂家名称',
  `device_type` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL COMMENT '设备类型',
  `device_type_name` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT '' COMMENT '设备类型名称',
  `device_model` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT '' COMMENT '设备型号',
  `device_model_name` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT '' COMMENT '型号名称',
  `icon` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT '' COMMENT '设备图标',
  `protocol` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT '' COMMENT '网络协议',
  `apps` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL DEFAULT '' COMMENT '支持应用',
  `support_child` tinyint(1) NOT NULL DEFAULT '0' COMMENT '支持子设备',
  `link_to` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL COMMENT '小程序跳转webview页面',
  `page_ctrl` json DEFAULT NULL COMMENT '页面配置',
  `ext_conf` json DEFAULT NULL COMMENT '后台内部扩展字段',
  `instance` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '0',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `idx_product_Key` (`product_key`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin ROW_FORMAT=DYNAMIC COMMENT='存储设备型号规格定义（关联产品型号、硬件版本）	';

-- ----------------------------
-- Records of iot_device_model
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for iot_device_protocol
-- ----------------------------
DROP TABLE IF EXISTS `iot_device_protocol`;
CREATE TABLE `iot_device_protocol` (
  `id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '产品key，product_key',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `description` varchar(1024) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `state` tinyint DEFAULT NULL COMMENT '0-未发布，1-已发布',
  `type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `configuration` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci COMMENT '配置信息',
  `example` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci COMMENT '编解码示例',
  `version` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '版本号',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `idx_create_time` (`create_time`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC COMMENT='设备协议表';

-- ----------------------------
-- Records of iot_device_protocol
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for iot_device_rule_log
-- ----------------------------
DROP TABLE IF EXISTS `iot_device_rule_log`;
CREATE TABLE `iot_device_rule_log` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `c_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '业务ID',
  `c_name` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '业务名称',
  `c_status` tinyint unsigned DEFAULT NULL COMMENT '执行状态：0-有失败、1-成功，2-失败',
  `c_type` tinyint unsigned DEFAULT NULL COMMENT '1-场景联动，2-数据流转',
  `conditions` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '条件',
  `c_device_meta` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin COMMENT '设备原始参数',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `create_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '',
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `idx_cid` (`c_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of iot_device_rule_log
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for iot_device_shadow
-- ----------------------------
DROP TABLE IF EXISTS `iot_device_shadow`;
CREATE TABLE `iot_device_shadow` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `iot_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '本平台设备唯一标识符',
  `product_key` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '产品Key',
  `device_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '设备自身序号',
  `ext_device_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '第三方平台设备ID唯一标识符',
  `active_time` datetime DEFAULT NULL COMMENT '激活时间',
  `online_time` datetime DEFAULT NULL COMMENT '在线时间',
  `last_time` datetime DEFAULT NULL COMMENT '最后通信时间',
  `metadata` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin COMMENT '影子数据',
  `instance` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '0' COMMENT '实例名称',
  `update_date` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `version` int unsigned DEFAULT '0' COMMENT '版本',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `dev_iot_id` (`iot_id`) USING BTREE,
  KEY `idx_pk_did` (`product_key`,`device_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin ROW_FORMAT=DYNAMIC COMMENT='设备影子表';

-- ----------------------------
-- Records of iot_device_shadow
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for iot_device_statistics
-- ----------------------------
DROP TABLE IF EXISTS `iot_device_statistics`;
CREATE TABLE `iot_device_statistics` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `stat_date` date NOT NULL COMMENT '统计日期',
  `product_key` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '产品Key',
  `total_devices` bigint NOT NULL DEFAULT '0' COMMENT '设备总数',
  `online_devices` bigint NOT NULL DEFAULT '0' COMMENT '在线设备数',
  `offline_devices` bigint NOT NULL DEFAULT '0' COMMENT '离线设备数',
  `new_devices` bigint NOT NULL DEFAULT '0' COMMENT '新增设备数',
  `active_devices` bigint NOT NULL DEFAULT '0' COMMENT '活跃设备数(当天有消息的设备)',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `uk_date_product` (`stat_date`,`product_key`) USING BTREE,
  KEY `idx_stat_date` (`stat_date`) USING BTREE,
  KEY `idx_product_key` (`product_key`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC COMMENT='设备统计表';

-- ----------------------------
-- Records of iot_device_statistics
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for iot_device_subscribe
-- ----------------------------
DROP TABLE IF EXISTS `iot_device_subscribe`;
CREATE TABLE `iot_device_subscribe` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `iot_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '设备唯一标识',
  `product_key` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '产品唯一标识',
  `device_id` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `msg_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '消息类别：属性（PROPERTIES），指令（REPLY），事件（EVENT），上下线（EVENT：online,offline），所有(ALL)',
  `sub_type` enum('DEVICE','PRODUCT') CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '订阅级别：设备级(DEVICE)，产品级（PRODUCT）',
  `url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '订阅地址',
  `topic` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '主题',
  `create_date` datetime DEFAULT NULL COMMENT '创建时间',
  `creater` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '创建人',
  `instance` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '0' COMMENT '实例编号',
  `enabled` tinyint(1) DEFAULT '1' COMMENT '是否启用',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `idx_iot_id` (`iot_id`) USING BTREE,
  KEY `iot_pd` (`product_key`,`device_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin ROW_FORMAT=DYNAMIC COMMENT='设备订阅';

-- ----------------------------
-- Records of iot_device_subscribe
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for iot_device_tags
-- ----------------------------
DROP TABLE IF EXISTS `iot_device_tags`;
CREATE TABLE `iot_device_tags` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `product_key` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `device_id` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `iot_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `create_time` bigint DEFAULT NULL,
  `name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `type` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `value` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `instance` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `dev_iot_id_idx` (`iot_id`) USING BTREE,
  KEY `dev_tag_idx` (`key`,`value`) USING BTREE,
  KEY `idx_pk_did` (`product_key`,`device_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC COMMENT='设备标签表';

-- ----------------------------
-- Records of iot_device_tags
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for iot_device_up_format
-- ----------------------------
DROP TABLE IF EXISTS `iot_device_up_format`;
CREATE TABLE `iot_device_up_format` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '费用名称',
  `apply` tinyint NOT NULL COMMENT '应用级别（1-应用 2-产品 3-所有）',
  `target_id` bigint NOT NULL COMMENT '目标ID（1-应用主键ID，2-ProductKey，3-0）',
  `cfg` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '模板配置',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `unionId` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '用户编号',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC COMMENT='消息格式化表';

-- ----------------------------
-- Records of iot_device_up_format
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for iot_gateway_polling_command
-- ----------------------------
DROP TABLE IF EXISTS `iot_gateway_polling_command`;
CREATE TABLE `iot_gateway_polling_command` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `gateway_product_key` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '网关产品KEY',
  `gateway_device_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '网关设备ID',
  `slave_device_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '从站设备ID (可选，用于标识)',
  `command_name` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '指令名称',
  `execution_order` int DEFAULT '0' COMMENT '执行顺序',
  `command_hex` varchar(1024) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '完整的轮询指令(HEX格式)',
  `command_type` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT 'MODBUS' COMMENT '指令类型: MODBUS/S7/OPCUA/CUSTOM',
  `protocol_params` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci COMMENT '协议参数JSON (可选，用于前端回显编辑)',
  `property_mapping` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci COMMENT '属性映射JSON (寄存器->物模型属性)',
  `data_parser_script` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci COMMENT '数据解析脚本 (可选)',
  `enabled` tinyint(1) DEFAULT '1' COMMENT '是否启用',
  `timeout_ms` int DEFAULT '5000' COMMENT '超时时间(ms)',
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '描述',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `idx_gateway` (`gateway_product_key`,`gateway_device_id`,`execution_order`) USING BTREE,
  KEY `idx_slave` (`slave_device_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='网关轮询指令表';

-- ----------------------------
-- Records of iot_gateway_polling_command
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for iot_gateway_polling_config
-- ----------------------------
DROP TABLE IF EXISTS `iot_gateway_polling_config`;
CREATE TABLE `iot_gateway_polling_config` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `device_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '网关设备ID',
  `product_key` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '产品KEY',
  `iot_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT 'IoT ID',
  `enabled` tinyint(1) DEFAULT '1' COMMENT '是否启用轮询: 0-禁用, 1-启用',
  `interval_seconds` int NOT NULL DEFAULT '120' COMMENT '轮询间隔(秒): 30/60/120/300/600',
  `timeout_seconds` int DEFAULT '10' COMMENT '超时时间(秒)',
  `retry_times` int DEFAULT '3' COMMENT '失败重试次数',
  `command_interval_ms` int DEFAULT '300' COMMENT '指令间隔(毫秒): 100-2000, 防止设备缓冲区溢出',
  `next_poll_time` datetime DEFAULT NULL COMMENT '下次轮询时间',
  `last_poll_time` datetime DEFAULT NULL COMMENT '最后轮询时间',
  `last_success_time` datetime DEFAULT NULL COMMENT '最后成功时间',
  `continuous_fail_count` int DEFAULT '0' COMMENT '连续失败次数',
  `polling_status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT 'NORMAL' COMMENT '轮询状态: NORMAL-正常, PAUSED-暂停, FAILED-失败',
  `total_poll_count` bigint DEFAULT '0' COMMENT '总轮询次数',
  `success_count` bigint DEFAULT '0' COMMENT '成功次数',
  `fail_count` bigint DEFAULT '0' COMMENT '失败次数',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `creator_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人ID',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `uk_device` (`product_key`,`device_id`) USING BTREE,
  KEY `idx_next_poll` (`interval_seconds`,`next_poll_time`,`polling_status`) USING BTREE,
  KEY `idx_product_key` (`product_key`) USING BTREE,
  KEY `idx_polling_due` (`interval_seconds`,`next_poll_time`,`polling_status`,`enabled`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='网关轮询配置表';

-- ----------------------------
-- Records of iot_gateway_polling_config
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for iot_network
-- ----------------------------
DROP TABLE IF EXISTS `iot_network`;
CREATE TABLE `iot_network` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT 'TCP_CLIENT,TCP_SERVER,MQTT_CLIENT,MQTT_SERVER',
  `union_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '网络唯一标识:MQTT为自定义惟一标识',
  `product_key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT 'ProductKey',
  `name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '网络组件名称',
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '详细描述',
  `configuration` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci COMMENT '配置内容',
  `create_user` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '创建用户',
  `create_date` datetime DEFAULT NULL COMMENT '创建时间',
  `state` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0-关闭，1-启动',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `uniq_network_pk_id` (`union_id`,`type`) USING BTREE COMMENT '网络组件唯一标识'
) ENGINE=InnoDB AUTO_INCREMENT=147 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC COMMENT='网络组件表';

-- ----------------------------
-- Records of iot_network
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for iot_product
-- ----------------------------
DROP TABLE IF EXISTS `iot_product`;
CREATE TABLE `iot_product` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `product_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '产品编号,当前等同设备型号',
  `company_no` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '厂商编号',
  `name` varchar(60) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '名称',
  `product_key` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '产品KEY',
  `third_platform` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '第三方平台:lvzhou,ctwing,onenet,alibaba,baidu',
  `classified_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '分类名称',
  `product_secret` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '产品密钥（1型1密）',
  `third_configuration` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci COMMENT '第三方平台配置信息',
  `classified_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '分类ID',
  `configuration` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci COMMENT '协议配置',
  `network_union_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '网络组件：TCP，MQTT',
  `device_node` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '设备节点: gateway(网关)，childrenDevice(网关子设备)，device(设备)',
  `gw_product_key` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '所属项目',
  `tags` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '标签字段',
  `message_protocol` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '消息协议: ',
  `creator_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '创建者id',
  `describe` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '说明',
  `store_policy` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '' COMMENT '数据存储策略',
  `store_policy_configuration` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci COMMENT '数据存储策略配置',
  `transport_protocol` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '传输协议: MQTT,COAP,UDP',
  `photo_url` varchar(2048) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '图片地址',
  `metadata` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci COMMENT '物模型',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `instance` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '0',
  `state` tinyint unsigned DEFAULT '0' COMMENT '产品状态（0-正常）',
  `third_down_request` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci COMMENT '第三方产品下发信息',
  `update_time` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `is_deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `idx_product_key` (`product_key`) USING BTREE COMMENT '产品唯一密钥',
  KEY `idx_prod_class_id` (`classified_id`) USING BTREE,
  KEY `idx_product_id` (`product_id`) USING BTREE COMMENT '产品ID（设备型号）',
  KEY `idx_product_creator_state_time` (`creator_id`,`state`,`create_time` DESC) USING BTREE,
  KEY `idx_product_creator_search` (`creator_id`,`product_key`,`name`) USING BTREE,
  KEY `idx_product_creator_classified` (`creator_id`,`classified_id`,`company_no`) USING BTREE,
  KEY `idx_product_creator_platform` (`creator_id`,`third_platform`,`device_node`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=10070 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC COMMENT='物联网产品基本信息（产品Key、协议类型、制造商）';

-- ----------------------------
-- Records of iot_product
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for iot_product_sort
-- ----------------------------
DROP TABLE IF EXISTS `iot_product_sort`;
CREATE TABLE `iot_product_sort` (
  `id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '分类id',
  `parent_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '父id',
  `has_child` tinyint(1) NOT NULL COMMENT '是否有子节点',
  `identification` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '标识',
  `classified_name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '分类名称',
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '说明',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `create_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '创建者',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin ROW_FORMAT=DYNAMIC COMMENT='产品分类';

-- ----------------------------
-- Records of iot_product_sort
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for iot_resource_connection
-- ----------------------------
DROP TABLE IF EXISTS `iot_resource_connection`;
CREATE TABLE `iot_resource_connection` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '资源名称',
  `type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '资源类型(MYSQL,KAFKA,MQTT,HTTP)',
  `plugin_type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '插件类型(JDBC,KAFKA,MQTT,HTTP,IOTDB等)',
  `host` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '主机地址',
  `port` int NOT NULL COMMENT '端口',
  `username` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '用户名',
  `password` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '密码',
  `database_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '数据库名/路径',
  `extra_config` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci COMMENT '扩展配置JSON',
  `status` tinyint DEFAULT '1' COMMENT '状态(0:禁用,1:启用)',
  `description` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '描述',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `create_by` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建者',
  `update_by` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新者',
  `direction` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT 'OUT' COMMENT '方向：IN-输入，OUT-输出',
  `data_direction` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT 'OUTPUT' COMMENT '数据流向：INPUT-输入，OUTPUT-输出，BIDIRECTIONAL-双向',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `idx_type` (`type`) USING BTREE,
  KEY `idx_status` (`status`) USING BTREE,
  KEY `idx_create_time` (`create_time`) USING BTREE,
  KEY `idx_direction` (`direction`) USING BTREE,
  KEY `idx_data_direction` (`data_direction`) USING BTREE,
  KEY `idx_plugin_type` (`plugin_type`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='资源连接表';

-- ----------------------------
-- Records of iot_resource_connection
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for iot_user
-- ----------------------------
DROP TABLE IF EXISTS `iot_user`;
CREATE TABLE `iot_user` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `org_id` bigint DEFAULT NULL COMMENT '归属组织机构',
  `username` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '用户名',
  `password` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '密码',
  `alias` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '别名',
  `union_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '用户唯一标识',
  `email` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '邮箱',
  `salt` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '密码加盐',
  `mobile` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '手机号',
  `status` tinyint unsigned DEFAULT NULL COMMENT '账号状态（0正常，1停用）',
  `avatar` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '头像',
  `parent_union_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '上级用户唯一id',
  `identity` tinyint NOT NULL DEFAULT '1' COMMENT '账号身份 0.超级管理员 1.普通用户 2.子用户',
  `login_ip` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '登录IP',
  `login_date` datetime DEFAULT NULL COMMENT '登录时间',
  `create_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '创建者',
  `create_date` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `update_date` datetime DEFAULT NULL,
  `cfg` varchar(1024) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '自定义配置',
  `remark` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '备注',
  `deleted` tinyint unsigned DEFAULT NULL COMMENT '0-正常，1-删除',
  `license` int unsigned DEFAULT '0' COMMENT '022租户接入数限制',
  `license_total_amount` int unsigned DEFAULT '1000' COMMENT 'license总额度',
  `register_from` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '注册来源',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1944353342247555073 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin ROW_FORMAT=DYNAMIC COMMENT='用户表';

-- ----------------------------
-- Records of iot_user
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for iot_user_application
-- ----------------------------
DROP TABLE IF EXISTS `iot_user_application`;
CREATE TABLE `iot_user_application` (
  `app_unique_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '应用标识',
  `union_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `app_name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '应用名称',
  `app_id` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '调用凭证APPID，必须16位',
  `up_topic` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'MQ上行主题，英文逗号分隔',
  `down_topic` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'MQ下行主题，英文逗号分隔',
  `notify_url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '回调地址',
  `app_secret` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '调用密钥，必须32位',
  `valid_end_date` datetime DEFAULT NULL COMMENT '授权结束时间',
  `scope` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '授权范围',
  `app_status` tinyint unsigned DEFAULT '0' COMMENT '0-正常，1-停用',
  `instance` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT 'public' COMMENT '实例名称',
  `remark` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '描述',
  `logo` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'logo',
  `create_date` datetime DEFAULT NULL COMMENT '创建时间',
  `cfg` json DEFAULT NULL COMMENT '额外配置',
  `deleted` tinyint unsigned DEFAULT '0' COMMENT '0-正常，1-删除',
  `http_enable` tinyint(1) DEFAULT '1' COMMENT 'http推送是否启用,0:不启用 1:启用',
  `mqtt_enable` tinyint(1) DEFAULT '1' COMMENT 'mqtt推送是否启用,0:不启用 1:启用',
  `tcp_enable` tinyint(1) DEFAULT '0' COMMENT 'tcp 809协议第三方推送是否启用  0不启用 1启用',
  PRIMARY KEY (`app_unique_id`) USING BTREE,
  UNIQUE KEY `idx_app_id` (`app_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin ROW_FORMAT=DYNAMIC COMMENT='用户应用信息表';

-- ----------------------------
-- Records of iot_user_application
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for iot_user_sub
-- ----------------------------
DROP TABLE IF EXISTS `iot_user_sub`;
CREATE TABLE `iot_user_sub` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `org_id` bigint DEFAULT NULL COMMENT '归属组织机构',
  `username` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '用户名',
  `password` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '密码',
  `alias` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '别名',
  `union_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '用户唯一标识',
  `email` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '邮箱',
  `salt` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '密码加盐',
  `mobile` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '手机号',
  `status` tinyint unsigned DEFAULT NULL COMMENT '账号状态（0正常，1停用）',
  `avatar` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '头像',
  `parent_union_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '上级用户唯一id',
  `identity` tinyint NOT NULL DEFAULT '2' COMMENT '账号身份 0.超级管理员 1.普通用户 2.子用户',
  `login_ip` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '登录IP',
  `login_date` datetime DEFAULT NULL COMMENT '登录时间',
  `create_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '创建者',
  `create_date` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `update_date` datetime DEFAULT NULL,
  `cfg` varchar(1024) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '自定义配置',
  `remark` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '备注',
  `deleted` tinyint unsigned DEFAULT NULL COMMENT '0-正常，1-删除',
  `license` int unsigned DEFAULT '0' COMMENT '022租户接入数限制',
  `license_total_amount` int unsigned DEFAULT '1000' COMMENT 'license总额度',
  `authorized_application_id` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '该账号有权限操作的应用id列表',
  `app_id` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '子账号用于oauth2认证的客户端id',
  `app_secret` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '子账号用于oauth2认证的客户端密钥',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin ROW_FORMAT=DYNAMIC COMMENT='子账号表';

-- ----------------------------
-- Records of iot_user_sub
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for notice_channel
-- ----------------------------
DROP TABLE IF EXISTS `notice_channel`;
CREATE TABLE `notice_channel` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '配置名称',
  `channel_type` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '渠道类型（如dingTalk、sms_ali、sms_tencent、feishu、wecom、email等）',
  `config` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '渠道参数(JSON字符串，如webhook、appKey、smtp等)',
  `status` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `remark` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '备注',
  `creator` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '创建人',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC COMMENT='通知notice_channel表';

-- ----------------------------
-- Records of notice_channel
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for notice_send_record
-- ----------------------------
DROP TABLE IF EXISTS `notice_send_record`;
CREATE TABLE `notice_send_record` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键',
  `template_id` bigint DEFAULT NULL COMMENT '模板ID',
  `config_id` bigint DEFAULT NULL COMMENT '通知配置ID',
  `receivers` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci COMMENT '实际收件人',
  `params` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci COMMENT '实际参数(JSON字符串)',
  `status` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '发送状态（如SUCCESS、FAIL）',
  `result` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci COMMENT '返回结果',
  `send_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '发送时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `idx_template_id` (`template_id`) USING BTREE,
  KEY `idx_config_id` (`config_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=271 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC COMMENT='通知发送记录表';

-- ----------------------------
-- Records of notice_send_record
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for notice_template
-- ----------------------------
DROP TABLE IF EXISTS `notice_template`;
CREATE TABLE `notice_template` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '模板名称',
  `channel_id` bigint NOT NULL COMMENT '关联的通知配置ID',
  `channel_type` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '渠道类型（如dingTalk、sms_ali、sms_tencent、feishu、wecom、email等）',
  `status` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '状态',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '模板内容（支持变量占位符）',
  `receivers` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci COMMENT '收件人（手机号、邮箱、群ID等，逗号分隔或JSON）',
  `remark` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '备注',
  `creator` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '创建人',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `idx_config_id` (`channel_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC COMMENT='通知模板表';

-- ----------------------------
-- Records of notice_template
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for oauth_client_details
-- ----------------------------
DROP TABLE IF EXISTS `oauth_client_details`;
CREATE TABLE `oauth_client_details` (
  `client_id` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '客户端标识',
  `resource_ids` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '资源标识',
  `client_secret` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '客户端秘钥',
  `scope` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `authorized_grant_types` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '授权类型\r\n	authorization_code：授权码模式\r\nrefresh_token：刷新token\r\npassword：密码模式\r\nimplicit：隐私授权模式\r\nclient_credentials：客户端模式',
  `web_server_redirect_uri` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '授权成功后回调URL',
  `authorities` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `access_token_validity` int DEFAULT NULL COMMENT '访问令牌的有效时间',
  `refresh_token_validity` int DEFAULT NULL COMMENT '刷新令牌的有效时间',
  `additional_information` varchar(4096) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '额外的信息，备用',
  `autoapprove` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '自动批准标识：0代表不显示授权页面  1显示授权页面',
  `username` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '用户名',
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '密码',
  `iot_union_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '唯一标识',
  PRIMARY KEY (`client_id`) USING BTREE,
  UNIQUE KEY `idx_unq_client_id` (`client_id`) USING BTREE COMMENT 'client_id唯一校验'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin ROW_FORMAT=DYNAMIC COMMENT='oauth2鉴权密钥表';

-- ----------------------------
-- Records of oauth_client_details
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for protocol_file
-- ----------------------------
DROP TABLE IF EXISTS `protocol_file`;
CREATE TABLE `protocol_file` (
  `file_path` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `file_content` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  PRIMARY KEY (`file_path`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of protocol_file
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for protocol_file_backup
-- ----------------------------
DROP TABLE IF EXISTS `protocol_file_backup`;
CREATE TABLE `protocol_file_backup` (
  `id` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '原对象ID',
  `create_date` bigint NOT NULL COMMENT '备份时间',
  `tag` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '标签',
  `type` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '类型',
  `name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '原名称',
  `content` blob COMMENT '备份内容',
  `create_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '操作人',
  PRIMARY KEY (`id`,`create_date`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of protocol_file_backup
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for qrtz_blob_triggers
-- ----------------------------
DROP TABLE IF EXISTS `qrtz_blob_triggers`;
CREATE TABLE `qrtz_blob_triggers` (
  `sched_name` varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '调度名称',
  `trigger_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT 'qrtz_triggers表trigger_name的外键',
  `trigger_group` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT 'qrtz_triggers表trigger_group的外键',
  `blob_data` blob COMMENT '存放持久化Trigger对象',
  PRIMARY KEY (`sched_name`,`trigger_name`,`trigger_group`) USING BTREE,
  CONSTRAINT `qrtz_blob_triggers_ibfk_1` FOREIGN KEY (`sched_name`, `trigger_name`, `trigger_group`) REFERENCES `qrtz_triggers` (`sched_name`, `trigger_name`, `trigger_group`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin ROW_FORMAT=DYNAMIC COMMENT='Blob类型的触发器表';

-- ----------------------------
-- Records of qrtz_blob_triggers
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for qrtz_calendars
-- ----------------------------
DROP TABLE IF EXISTS `qrtz_calendars`;
CREATE TABLE `qrtz_calendars` (
  `sched_name` varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '调度名称',
  `calendar_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '日历名称',
  `calendar` blob NOT NULL COMMENT '存放持久化calendar对象',
  PRIMARY KEY (`sched_name`,`calendar_name`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin ROW_FORMAT=DYNAMIC COMMENT='日历信息表';

-- ----------------------------
-- Records of qrtz_calendars
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for qrtz_cron_triggers
-- ----------------------------
DROP TABLE IF EXISTS `qrtz_cron_triggers`;
CREATE TABLE `qrtz_cron_triggers` (
  `sched_name` varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '调度名称',
  `trigger_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT 'qrtz_triggers表trigger_name的外键',
  `trigger_group` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT 'qrtz_triggers表trigger_group的外键',
  `cron_expression` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT 'cron表达式',
  `time_zone_id` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '时区',
  PRIMARY KEY (`sched_name`,`trigger_name`,`trigger_group`) USING BTREE,
  CONSTRAINT `qrtz_cron_triggers_ibfk_1` FOREIGN KEY (`sched_name`, `trigger_name`, `trigger_group`) REFERENCES `qrtz_triggers` (`sched_name`, `trigger_name`, `trigger_group`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin ROW_FORMAT=DYNAMIC COMMENT='Cron类型的触发器表';

-- ----------------------------
-- Records of qrtz_cron_triggers
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for qrtz_fired_triggers
-- ----------------------------
DROP TABLE IF EXISTS `qrtz_fired_triggers`;
CREATE TABLE `qrtz_fired_triggers` (
  `sched_name` varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '调度名称',
  `entry_id` varchar(95) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '调度器实例id',
  `trigger_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT 'qrtz_triggers表trigger_name的外键',
  `trigger_group` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT 'qrtz_triggers表trigger_group的外键',
  `instance_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '调度器实例名',
  `fired_time` bigint NOT NULL COMMENT '触发的时间',
  `sched_time` bigint NOT NULL COMMENT '定时器制定的时间',
  `priority` int NOT NULL COMMENT '优先级',
  `state` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '状态',
  `job_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '任务名称',
  `job_group` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '任务组名',
  `is_nonconcurrent` varchar(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '是否并发',
  `requests_recovery` varchar(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '是否接受恢复执行',
  PRIMARY KEY (`sched_name`,`entry_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin ROW_FORMAT=DYNAMIC COMMENT='已触发的触发器表';

-- ----------------------------
-- Records of qrtz_fired_triggers
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for qrtz_job_details
-- ----------------------------
DROP TABLE IF EXISTS `qrtz_job_details`;
CREATE TABLE `qrtz_job_details` (
  `sched_name` varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '调度名称',
  `job_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '任务名称',
  `job_group` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '任务组名',
  `description` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '相关介绍',
  `job_class_name` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '执行任务类名称',
  `is_durable` varchar(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '是否持久化',
  `is_nonconcurrent` varchar(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '是否并发',
  `is_update_data` varchar(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '是否更新数据',
  `requests_recovery` varchar(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '是否接受恢复执行',
  `job_data` blob COMMENT '存放持久化job对象',
  PRIMARY KEY (`sched_name`,`job_name`,`job_group`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin ROW_FORMAT=DYNAMIC COMMENT='任务详细信息表';

-- ----------------------------
-- Records of qrtz_job_details
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for qrtz_locks
-- ----------------------------
DROP TABLE IF EXISTS `qrtz_locks`;
CREATE TABLE `qrtz_locks` (
  `sched_name` varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '调度名称',
  `lock_name` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '悲观锁名称',
  PRIMARY KEY (`sched_name`,`lock_name`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin ROW_FORMAT=DYNAMIC COMMENT='存储的悲观锁信息表';

-- ----------------------------
-- Records of qrtz_locks
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for qrtz_paused_trigger_grps
-- ----------------------------
DROP TABLE IF EXISTS `qrtz_paused_trigger_grps`;
CREATE TABLE `qrtz_paused_trigger_grps` (
  `sched_name` varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '调度名称',
  `trigger_group` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT 'qrtz_triggers表trigger_group的外键',
  PRIMARY KEY (`sched_name`,`trigger_group`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin ROW_FORMAT=DYNAMIC COMMENT='暂停的触发器表';

-- ----------------------------
-- Records of qrtz_paused_trigger_grps
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for qrtz_scheduler_state
-- ----------------------------
DROP TABLE IF EXISTS `qrtz_scheduler_state`;
CREATE TABLE `qrtz_scheduler_state` (
  `sched_name` varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '调度名称',
  `instance_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '实例名称',
  `last_checkin_time` bigint NOT NULL COMMENT '上次检查时间',
  `checkin_interval` bigint NOT NULL COMMENT '检查间隔时间',
  PRIMARY KEY (`sched_name`,`instance_name`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin ROW_FORMAT=DYNAMIC COMMENT='调度器状态表';

-- ----------------------------
-- Records of qrtz_scheduler_state
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for qrtz_simple_triggers
-- ----------------------------
DROP TABLE IF EXISTS `qrtz_simple_triggers`;
CREATE TABLE `qrtz_simple_triggers` (
  `sched_name` varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '调度名称',
  `trigger_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT 'qrtz_triggers表trigger_name的外键',
  `trigger_group` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT 'qrtz_triggers表trigger_group的外键',
  `repeat_count` bigint NOT NULL COMMENT '重复的次数统计',
  `repeat_interval` bigint NOT NULL COMMENT '重复的间隔时间',
  `times_triggered` bigint NOT NULL COMMENT '已经触发的次数',
  PRIMARY KEY (`sched_name`,`trigger_name`,`trigger_group`) USING BTREE,
  CONSTRAINT `qrtz_simple_triggers_ibfk_1` FOREIGN KEY (`sched_name`, `trigger_name`, `trigger_group`) REFERENCES `qrtz_triggers` (`sched_name`, `trigger_name`, `trigger_group`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin ROW_FORMAT=DYNAMIC COMMENT='简单触发器的信息表';

-- ----------------------------
-- Records of qrtz_simple_triggers
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for qrtz_simprop_triggers
-- ----------------------------
DROP TABLE IF EXISTS `qrtz_simprop_triggers`;
CREATE TABLE `qrtz_simprop_triggers` (
  `sched_name` varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '调度名称',
  `trigger_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT 'qrtz_triggers表trigger_name的外键',
  `trigger_group` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT 'qrtz_triggers表trigger_group的外键',
  `str_prop_1` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'String类型的trigger的第一个参数',
  `str_prop_2` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'String类型的trigger的第二个参数',
  `str_prop_3` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'String类型的trigger的第三个参数',
  `int_prop_1` int DEFAULT NULL COMMENT 'int类型的trigger的第一个参数',
  `int_prop_2` int DEFAULT NULL COMMENT 'int类型的trigger的第二个参数',
  `long_prop_1` bigint DEFAULT NULL COMMENT 'long类型的trigger的第一个参数',
  `long_prop_2` bigint DEFAULT NULL COMMENT 'long类型的trigger的第二个参数',
  `dec_prop_1` decimal(13,4) DEFAULT NULL COMMENT 'decimal类型的trigger的第一个参数',
  `dec_prop_2` decimal(13,4) DEFAULT NULL COMMENT 'decimal类型的trigger的第二个参数',
  `bool_prop_1` varchar(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'Boolean类型的trigger的第一个参数',
  `bool_prop_2` varchar(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'Boolean类型的trigger的第二个参数',
  PRIMARY KEY (`sched_name`,`trigger_name`,`trigger_group`) USING BTREE,
  CONSTRAINT `qrtz_simprop_triggers_ibfk_1` FOREIGN KEY (`sched_name`, `trigger_name`, `trigger_group`) REFERENCES `qrtz_triggers` (`sched_name`, `trigger_name`, `trigger_group`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin ROW_FORMAT=DYNAMIC COMMENT='同步机制的行锁表';

-- ----------------------------
-- Records of qrtz_simprop_triggers
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for qrtz_triggers
-- ----------------------------
DROP TABLE IF EXISTS `qrtz_triggers`;
CREATE TABLE `qrtz_triggers` (
  `sched_name` varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '调度名称',
  `trigger_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '触发器的名字',
  `trigger_group` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '触发器所属组的名字',
  `job_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT 'qrtz_job_details表job_name的外键',
  `job_group` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT 'qrtz_job_details表job_group的外键',
  `description` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '相关介绍',
  `next_fire_time` bigint DEFAULT NULL COMMENT '上一次触发时间（毫秒）',
  `prev_fire_time` bigint DEFAULT NULL COMMENT '下一次触发时间（默认为-1表示不触发）',
  `priority` int DEFAULT NULL COMMENT '优先级',
  `trigger_state` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '触发器状态',
  `trigger_type` varchar(8) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '触发器的类型',
  `start_time` bigint NOT NULL COMMENT '开始时间',
  `end_time` bigint DEFAULT NULL COMMENT '结束时间',
  `calendar_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '日程表名称',
  `misfire_instr` smallint DEFAULT NULL COMMENT '补偿执行的策略',
  `job_data` blob COMMENT '存放持久化job对象',
  PRIMARY KEY (`sched_name`,`trigger_name`,`trigger_group`) USING BTREE,
  KEY `sched_name` (`sched_name`,`job_name`,`job_group`) USING BTREE,
  CONSTRAINT `qrtz_triggers_ibfk_1` FOREIGN KEY (`sched_name`, `job_name`, `job_group`) REFERENCES `qrtz_job_details` (`sched_name`, `job_name`, `job_group`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin ROW_FORMAT=DYNAMIC COMMENT='触发器详细信息表';

-- ----------------------------
-- Records of qrtz_triggers
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for rule_model
-- ----------------------------
DROP TABLE IF EXISTS `rule_model`;
CREATE TABLE `rule_model` (
  `id` bigint NOT NULL COMMENT 'id',
  `rule_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '规则名称',
  `data_level` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '数据级别',
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '描述',
  `status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '状态',
  `product_key` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '产品KEY',
  `config` json DEFAULT NULL COMMENT '规则配置',
  `creator_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '创建人',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin ROW_FORMAT=DYNAMIC COMMENT='规则模型';

-- ----------------------------
-- Records of rule_model
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for rule_model_instance
-- ----------------------------
DROP TABLE IF EXISTS `rule_model_instance`;
CREATE TABLE `rule_model_instance` (
  `id` bigint NOT NULL COMMENT 'id',
  `model_id` bigint DEFAULT NULL COMMENT '模型id',
  `relation_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '关联类型',
  `relation_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '关联id',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin ROW_FORMAT=DYNAMIC COMMENT='规则实例';

-- ----------------------------
-- Records of rule_model_instance
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for rulego_chain
-- ----------------------------
DROP TABLE IF EXISTS `rulego_chain`;
CREATE TABLE `rulego_chain` (
  `id` bigint NOT NULL COMMENT '主键ID',
  `rulego_id` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT 'rulego规则链ID',
  `chain_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '规则链名称',
  `description` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '规则链描述',
  `creator_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '创建人unionId',
  `creator_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '创建人姓名',
  `status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT 'draft' COMMENT '状态：draft-草稿，deployed-已部署，stopped-已停止',
  `dsl_content` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin COMMENT '规则链DSL内容(JSON格式)',
  `last_sync_time` datetime DEFAULT NULL COMMENT '最后同步时间',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted` tinyint(1) DEFAULT '0' COMMENT '是否删除：0-未删除，1-已删除',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `uk_rulego_id` (`rulego_id`) USING BTREE,
  KEY `idx_creator_id` (`creator_id`) USING BTREE,
  KEY `idx_status` (`status`) USING BTREE,
  KEY `idx_create_time` (`create_time`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin ROW_FORMAT=DYNAMIC COMMENT='rulego规则链管理表';

-- ----------------------------
-- Records of rulego_chain
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for rulego_chain_log
-- ----------------------------
DROP TABLE IF EXISTS `rulego_chain_log`;
CREATE TABLE `rulego_chain_log` (
  `id` bigint NOT NULL COMMENT '主键ID',
  `rulego_id` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT 'rulego规则链ID',
  `chain_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '规则链名称',
  `execution_id` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '执行ID',
  `input_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin COMMENT '输入数据',
  `output_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin COMMENT '输出数据',
  `execution_status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '执行状态：success-成功，failed-失败',
  `error_message` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin COMMENT '错误信息',
  `execution_time` bigint DEFAULT NULL COMMENT '执行耗时(毫秒)',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `idx_rulego_id` (`rulego_id`) USING BTREE,
  KEY `idx_execution_id` (`execution_id`) USING BTREE,
  KEY `idx_create_time` (`create_time`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin ROW_FORMAT=DYNAMIC COMMENT='rulego规则链执行日志表';

-- ----------------------------
-- Records of rulego_chain_log
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for scene_linkage
-- ----------------------------
DROP TABLE IF EXISTS `scene_linkage`;
CREATE TABLE `scene_linkage` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `scene_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '场景名称',
  `touch` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT 'one' COMMENT '触发条件 all.全部 one.任意一个',
  `trigger_condition` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin COMMENT '触发条件',
  `exec_action` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin COMMENT '执行动作',
  `sleep_cycle` int DEFAULT NULL COMMENT '沉默周期',
  `create_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `update_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `status` tinyint DEFAULT '0' COMMENT '0启用 1停用',
  `dev_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '设备id',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=92 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin ROW_FORMAT=DYNAMIC COMMENT='场景联动';

-- ----------------------------
-- Records of scene_linkage
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for support_map_areas
-- ----------------------------
DROP TABLE IF EXISTS `support_map_areas`;
CREATE TABLE `support_map_areas` (
  `id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT 'id',
  `pid` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '父id',
  `name` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '地址',
  `full_name` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '详细地址',
  `deep` varchar(5) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '深度',
  `location` geometry NOT NULL COMMENT '核心点坐标',
  `polygon` geometry NOT NULL COMMENT '范围坐标',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `pid_index` (`pid`) USING BTREE,
  SPATIAL KEY `sp_index` (`polygon`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of support_map_areas
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for sys_config
-- ----------------------------
DROP TABLE IF EXISTS `sys_config`;
CREATE TABLE `sys_config` (
  `config_id` int NOT NULL AUTO_INCREMENT COMMENT '参数主键',
  `config_name` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT '' COMMENT '参数名称',
  `config_key` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT '' COMMENT '参数键名',
  `config_value` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT '' COMMENT '参数键值',
  `config_type` char(1) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT 'N' COMMENT '系统内置（Y是 N否）',
  `create_by` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT '' COMMENT '创建者',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT '' COMMENT '更新者',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `remark` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`config_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb3 ROW_FORMAT=DYNAMIC COMMENT='参数配置表';

-- ----------------------------
-- Records of sys_config
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for sys_dict_data
-- ----------------------------
DROP TABLE IF EXISTS `sys_dict_data`;
CREATE TABLE `sys_dict_data` (
  `dict_code` bigint NOT NULL AUTO_INCREMENT COMMENT '字典编码',
  `dict_sort` int DEFAULT '0' COMMENT '字典排序',
  `dict_label` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '字典标签',
  `dict_value` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '字典键值',
  `dict_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT '' COMMENT '字典类型',
  `css_class` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL COMMENT '样式属性（其他样式扩展）',
  `list_class` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL COMMENT '表格回显样式',
  `is_default` char(1) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT 'N' COMMENT '是否默认（Y是 N否）',
  `status` char(1) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT '0' COMMENT '状态（0正常 1停用）',
  `create_by` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT '' COMMENT '创建者',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT '' COMMENT '更新者',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`dict_code`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=795 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin ROW_FORMAT=DYNAMIC COMMENT='字典数据表';

-- ----------------------------
-- Records of sys_dict_data
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for sys_dict_type
-- ----------------------------
DROP TABLE IF EXISTS `sys_dict_type`;
CREATE TABLE `sys_dict_type` (
  `dict_id` bigint NOT NULL AUTO_INCREMENT COMMENT '字典主键',
  `dict_name` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT '' COMMENT '字典名称',
  `dict_type` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT '' COMMENT '字典类型',
  `status` char(1) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT '0' COMMENT '状态（0正常 1停用）',
  `create_by` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT '' COMMENT '创建者',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT '' COMMENT '更新者',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `remark` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`dict_id`) USING BTREE,
  UNIQUE KEY `dict_type` (`dict_type`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=214 DEFAULT CHARSET=utf8mb3 ROW_FORMAT=DYNAMIC COMMENT='字典类型表';

-- ----------------------------
-- Records of sys_dict_type
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for sys_job
-- ----------------------------
DROP TABLE IF EXISTS `sys_job`;
CREATE TABLE `sys_job` (
  `job_id` bigint NOT NULL AUTO_INCREMENT COMMENT '任务ID',
  `job_name` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL DEFAULT '' COMMENT '任务名称',
  `job_group` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL DEFAULT 'DEFAULT' COMMENT '任务组名',
  `invoke_target` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL COMMENT '调用目标字符串',
  `cron_expression` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT '' COMMENT 'cron执行表达式',
  `misfire_policy` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT '3' COMMENT '计划执行错误策略（1立即执行 2执行一次 3放弃执行）',
  `concurrent` char(1) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT '1' COMMENT '是否并发执行（0允许 1禁止）',
  `status` char(1) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT '0' COMMENT '状态（0正常 1暂停）',
  `create_by` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT '' COMMENT '创建者',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT '' COMMENT '更新者',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `remark` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT '' COMMENT '备注信息',
  PRIMARY KEY (`job_id`,`job_name`,`job_group`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb3 ROW_FORMAT=DYNAMIC COMMENT='定时任务调度表';

-- ----------------------------
-- Records of sys_job
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for sys_job_log
-- ----------------------------
DROP TABLE IF EXISTS `sys_job_log`;
CREATE TABLE `sys_job_log` (
  `job_log_id` bigint NOT NULL AUTO_INCREMENT COMMENT '日志ID',
  `job_name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '任务名称',
  `job_group` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '任务组名',
  `invoke_target` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '调用目标字符串',
  `status` tinyint NOT NULL COMMENT '执行状态（0成功 1失败）',
  `job_message` varchar(2000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '任务信息',
  `exception_info` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci COMMENT '异常信息',
  `start_time` datetime DEFAULT NULL COMMENT '开始时间',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`job_log_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC COMMENT='定时任务日志表';

-- ----------------------------
-- Records of sys_job_log
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for sys_logininfor
-- ----------------------------
DROP TABLE IF EXISTS `sys_logininfor`;
CREATE TABLE `sys_logininfor` (
  `info_id` bigint NOT NULL AUTO_INCREMENT COMMENT '访问ID',
  `user_name` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT '' COMMENT '用户账号',
  `ipaddr` varchar(128) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT '' COMMENT '登录IP地址',
  `login_location` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT '' COMMENT '登录地点',
  `browser` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT '' COMMENT '浏览器类型',
  `os` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT '' COMMENT '操作系统',
  `status` char(1) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT '0' COMMENT '登录状态（0成功 1失败）',
  `msg` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT '' COMMENT '提示消息',
  `login_time` datetime DEFAULT NULL COMMENT '访问时间',
  PRIMARY KEY (`info_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2991 DEFAULT CHARSET=utf8mb3 ROW_FORMAT=DYNAMIC COMMENT='系统访问记录';

-- ----------------------------
-- Records of sys_logininfor
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for sys_menu
-- ----------------------------
DROP TABLE IF EXISTS `sys_menu`;
CREATE TABLE `sys_menu` (
  `menu_id` bigint NOT NULL AUTO_INCREMENT COMMENT '菜单ID',
  `menu_name` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL COMMENT '菜单名称',
  `parent_id` bigint DEFAULT '0' COMMENT '父菜单ID',
  `order_num` int DEFAULT '0' COMMENT '显示顺序',
  `path` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT '' COMMENT '路由地址',
  `component` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL COMMENT '组件路径',
  `is_frame` int DEFAULT '1' COMMENT '是否为外链（0是 1否）',
  `is_cache` int DEFAULT '0' COMMENT '是否缓存（0缓存 1不缓存）',
  `menu_type` char(1) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT '' COMMENT '菜单类型（M目录 C菜单 F按钮）',
  `visible` char(1) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT '0' COMMENT '菜单状态（0显示 1隐藏）',
  `status` char(1) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT '0' COMMENT '菜单状态（0正常 1停用）',
  `perms` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL COMMENT '权限标识',
  `icon` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT '#' COMMENT '菜单图标',
  `create_by` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT '' COMMENT '创建者',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT '' COMMENT '更新者',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `remark` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT '' COMMENT '备注',
  PRIMARY KEY (`menu_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1282 DEFAULT CHARSET=utf8mb3 ROW_FORMAT=DYNAMIC COMMENT='菜单权限表';

-- ----------------------------
-- Records of sys_menu
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for sys_notice
-- ----------------------------
DROP TABLE IF EXISTS `sys_notice`;
CREATE TABLE `sys_notice` (
  `notice_id` int NOT NULL AUTO_INCREMENT COMMENT '公告ID',
  `notice_title` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '公告标题',
  `notice_type` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '公告类型（1通知 2公告）',
  `notice_content` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci COMMENT '公告内容',
  `status` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT '0' COMMENT '公告状态（0正常 1关闭）',
  `create_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT '' COMMENT '创建者',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT '' COMMENT '更新者',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `remark` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`notice_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='通知公告表';

-- ----------------------------
-- Records of sys_notice
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for sys_oper_log
-- ----------------------------
DROP TABLE IF EXISTS `sys_oper_log`;
CREATE TABLE `sys_oper_log` (
  `oper_id` bigint NOT NULL AUTO_INCREMENT COMMENT '日志主键',
  `title` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT '' COMMENT '模块标题',
  `business_type` int DEFAULT '0' COMMENT '业务类型（0其它 1新增 2修改 3删除）',
  `method` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT '' COMMENT '方法名称',
  `request_method` varchar(10) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT '' COMMENT '请求方式',
  `operator_type` int DEFAULT '0' COMMENT '操作类别（0其它 1后台用户 2手机端用户）',
  `oper_name` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT '' COMMENT '操作人员',
  `dept_name` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT '' COMMENT '部门名称',
  `oper_url` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT '' COMMENT '请求URL',
  `oper_ip` varchar(128) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT '' COMMENT '主机地址',
  `oper_location` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT '' COMMENT '操作地点',
  `oper_param` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin COMMENT '请求参数',
  `json_result` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci COMMENT '返回参数',
  `status` int DEFAULT '0' COMMENT '操作状态（0正常 1异常）',
  `error_msg` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci COMMENT '错误消息',
  `oper_time` datetime DEFAULT NULL COMMENT '操作时间',
  PRIMARY KEY (`oper_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=6812 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin ROW_FORMAT=DYNAMIC COMMENT='操作日志记录';

-- ----------------------------
-- Records of sys_oper_log
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for sys_oss
-- ----------------------------
DROP TABLE IF EXISTS `sys_oss`;
CREATE TABLE `sys_oss` (
  `oss_id` bigint NOT NULL AUTO_INCREMENT COMMENT '云存储主键',
  `file_name` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL DEFAULT '' COMMENT '文件名',
  `original_name` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL DEFAULT '' COMMENT '原名',
  `file_suffix` varchar(10) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL DEFAULT '' COMMENT '文件后缀名',
  `url` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL COMMENT 'URL地址',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `create_by` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT '' COMMENT '上传人',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `update_by` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT '' COMMENT '更新人',
  `service` varchar(10) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL DEFAULT 'minio' COMMENT '服务商',
  PRIMARY KEY (`oss_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb3 ROW_FORMAT=DYNAMIC COMMENT='OSS云存储表';

-- ----------------------------
-- Records of sys_oss
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for sys_role
-- ----------------------------
DROP TABLE IF EXISTS `sys_role`;
CREATE TABLE `sys_role` (
  `role_id` bigint NOT NULL AUTO_INCREMENT COMMENT '角色ID',
  `role_name` varchar(30) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL COMMENT '角色名称',
  `role_key` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL COMMENT '角色权限字符串',
  `role_sort` int NOT NULL COMMENT '显示顺序',
  `data_scope` char(1) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT '1' COMMENT '数据范围（1：全部数据权限 2：自定数据权限 3：本部门数据权限 4：本部门及以下数据权限）',
  `menu_check_strictly` tinyint(1) DEFAULT '1' COMMENT '菜单树选择项是否关联显示',
  `dept_check_strictly` tinyint(1) DEFAULT '1' COMMENT '部门树选择项是否关联显示',
  `status` char(1) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL COMMENT '角色状态（0正常 1停用）',
  `create_by` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT '' COMMENT '创建者',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT '' COMMENT '更新者',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `remark` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`role_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb3 ROW_FORMAT=DYNAMIC COMMENT='角色信息表';

-- ----------------------------
-- Records of sys_role
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for sys_role_menu
-- ----------------------------
DROP TABLE IF EXISTS `sys_role_menu`;
CREATE TABLE `sys_role_menu` (
  `role_id` bigint NOT NULL COMMENT '角色ID',
  `menu_id` bigint NOT NULL COMMENT '菜单ID',
  `uuid` bigint NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`uuid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2552 DEFAULT CHARSET=utf8mb3 ROW_FORMAT=DYNAMIC COMMENT='角色和菜单关联表';

-- ----------------------------
-- Records of sys_role_menu
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for sys_user_role
-- ----------------------------
DROP TABLE IF EXISTS `sys_user_role`;
CREATE TABLE `sys_user_role` (
  `uuid` bigint NOT NULL AUTO_INCREMENT,
  `union_id` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL COMMENT '用户unionId',
  `role_id` bigint NOT NULL COMMENT '角色ID',
  PRIMARY KEY (`uuid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3 ROW_FORMAT=DYNAMIC COMMENT='用户和角色关联表';

-- ----------------------------
-- Records of sys_user_role
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Procedure structure for auto_add_partition_for_all_shards
-- ----------------------------
DROP PROCEDURE IF EXISTS `auto_add_partition_for_all_shards`;
delimiter ;;
CREATE DEFINER=`root`@`%` PROCEDURE `auto_add_partition_for_all_shards`()
BEGIN
    -- 变量定义：分表索引（0~23）、时间、分区名、表名
    DECLARE `shard_idx` INT DEFAULT 0;
    DECLARE `next_month` DATE;
    DECLARE `next_next_month` DATE;
    DECLARE `partition_name` VARCHAR(20);
    DECLARE `log_table_name` VARCHAR(50); -- log分表名（如iot_device_log_0）
    DECLARE `metadata_table_name` VARCHAR(50); -- metadata分表名（如iot_device_log_metadata_0）

    -- 1. 计算分区时间：下月1号（分区名）、下下月1号（分区边界）
    SET `next_month` = DATE_FORMAT(CURDATE() + INTERVAL 1 MONTH, '%Y-%m-01');
    SET `next_next_month` = DATE_FORMAT(CURDATE() + INTERVAL 2 MONTH, '%Y-%m-01');
    SET `partition_name` = CONCAT('p', DATE_FORMAT(`next_month`, '%Y%m')); -- 分区名：p202512

    -- 2. 循环处理0~23所有分表（同时处理log和metadata分表）
    WHILE `shard_idx` < 24 DO
        -- 2.1 拼接当前分表名
        SET `log_table_name` = CONCAT('iot_device_log_', `shard_idx`);
        SET `metadata_table_name` = CONCAT('iot_device_log_metadata_', `shard_idx`);

        -- 2.2 为 log分表 新增分区
        SET @sql_log = CONCAT(
            'ALTER TABLE ', `log_table_name`, ' ADD PARTITION (',
            'PARTITION ', `partition_name`, ' VALUES LESS THAN (TO_DAYS(\'', `next_next_month`, '\'))',
            ');'
        );
        PREPARE stmt_log FROM @sql_log;
        EXECUTE stmt_log;
        DEALLOCATE PREPARE stmt_log;

        -- 2.3 为 metadata分表 新增分区（与log分表对齐）
        SET @sql_metadata = CONCAT(
            'ALTER TABLE ', `metadata_table_name`, ' ADD PARTITION (',
            'PARTITION ', `partition_name`, ' VALUES LESS THAN (TO_DAYS(\'', `next_next_month`, '\'))',
            ');'
        );
        PREPARE stmt_metadata FROM @sql_metadata;
        EXECUTE stmt_metadata;
        DEALLOCATE PREPARE stmt_metadata;

        -- 2.4 打印执行结果（便于验证）
        SELECT 
            CONCAT('✅ 已为分表 [', `log_table_name`, '] 和 [', `metadata_table_name`, '] 新增分区：', `partition_name`) AS `result`;

        -- 分表索引+1，继续下一张
        SET `shard_idx` = `shard_idx` + 1;
    END WHILE;

    -- 3. 最终提示
    SELECT CONCAT('🎉 所有分表分区新增完成！本次新增分区：', `partition_name`, '，时间范围：', `next_month`, ' ~ ', DATE_SUB(`next_next_month`, INTERVAL 1 DAY)) AS `final_result`;
END
;;
delimiter ;

SET FOREIGN_KEY_CHECKS = 1;
